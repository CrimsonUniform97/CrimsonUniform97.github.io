---- About ----

This package is only needed if you wish to host your own Blast Passage server.
If you just wish to play the game, simply visit http://www.mojang.com/notch/blastpassage/

Note that this file is not needed if you wish to play on a hosted server, only the person
hosting the game needs to do anything!



---- Starting the server ----

1) Run the "start server.bat" file
2) Find out what your public ip number is
     For example, you can run the command "ipconfig" from the command prompt,
     or you can visit the site http://www.whatismyip.org/
3) Tell the people you want to play with to surf to http://<your ip number>:27001/
     They should then select the "Online multiplayer" option in the main menu



---- Advanced ----

If you're not running on windows, use the following command from the command line to start the server:

java -cp lib/blastpassageserver.jar;lib/webserver.jar;lib/servlet.jar com.mojang.blastpassage.Webserver


If you wish to host the game from a custom html server, do this:

1) Copy the file lib/blastpassageserver.jar to your server
2) Start the server with the command java -cp blastpassageserver.jar com.mojang.blastpassage.server.Server
3) Copy the contents of web to somewhere on your web server



---- Legal ----

The Blast Passage server uses Tiny Java Web Server available at http://tjws.sourceforge.net/

Everything else is copyright 2008 (c) Markus Persson.
Please don't remove the link to my home page from the html page hosting the game applet.

TJWS license:

 * Copyright (C) 1999-2004 Dmitriy Rogatkin.  All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.