INFINIMINER

A GAME BY ZACHTRONICS INDUSTRIES

http://www.zachtronicsindustries.com

HELP:

Hold down the F1 key while in-game.

MUSIC:

http://www.8bitcollective.com/music/Kola+Kid/can%27t+hide+your+love/