package com.mojang.metagun.entity;

public class BossPart extends Entity {
    public int dieIn = 0;

    public void setRot(double rot) {
    }

    public void outOfBounds() {
    }
}