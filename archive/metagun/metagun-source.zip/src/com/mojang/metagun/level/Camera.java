package com.mojang.metagun.level;

public class Camera {
    public int x, y, width, height;
    
    public Camera(int width, int height) {
        this.width = width;
        this.height = height;
    }
}