

     METAGUN Source code release
     ---------------------------


This is the source code for Metagun, as required by the Ludum Dare rules.
Everything in here is Copyright Markus Persson.

You may do whatever you want with this as long as you give me credit.



The source code was hurried together over 48 hours, and is totally undocumented.
There's plenty of hacks and needlessly duplicated code, but it should be at least somewhat readable.

Have fun!



Markus Persson, August 2010
markus@mojang.com

