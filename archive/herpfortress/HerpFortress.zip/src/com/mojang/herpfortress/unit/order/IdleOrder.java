package com.mojang.herpfortress.unit.order;

public class IdleOrder extends Order {
	public void tick() {
	}

	public boolean finished() {
		return true;
	}
}