package com.mojang.herpfortress;

public enum Team {
	blu, red;
}
