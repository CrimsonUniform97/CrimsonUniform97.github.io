package com.mojang.herpfortress.particle;

import com.mojang.herpfortress.Sprite;

public class Particle extends Sprite {

}