package com.mojang.tower;

public class TargetFilter
{
    public boolean accepts(Entity e)
    {
        return true;
    }
}
