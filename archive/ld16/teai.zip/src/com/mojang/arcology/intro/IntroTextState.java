package com.mojang.arcology.intro;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;

public class IntroTextState extends State {
	private BufferedReader br;
	private boolean done = false;
	private String[] lines = new String[30];

	public IntroTextState() {
		readNext();
	}

	public void readNext() {
		for (int i = 0; i < 30; i++) {
			lines[i] = "";
		}
		if (br == null) {
			br = new BufferedReader(new InputStreamReader(IntroTextState.class.getResourceAsStream("intro.txt")));
		}
		String line = "";
		int row = 3;
		try {

			while ((line = br.readLine()) != null) {
				if (line.startsWith("-")) {
					break;
				}
				if (line.length() > 2) {
					lines[row] = "�" + line;
				}
				row++;
			}
			if (line == null) done = true;
		} catch (Exception e) {
			e.printStackTrace();
			done = true;
		}
	}

	public void display(Screen screen) {
		screen.clear();

		for (int i = 0; i < 30; i++) {
			screen.drawString(lines[i], 3, i, 7);
		}
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_ACTION) {
			if (!done) {
				readNext();
			} else {
				setState(new CharGenState());
			}
		}
		if (key == KEY_BACK) {
			setState(new CharGenState());
		}
	}
}
