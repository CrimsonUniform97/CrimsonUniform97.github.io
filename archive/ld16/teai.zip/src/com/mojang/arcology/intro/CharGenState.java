package com.mojang.arcology.intro;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.game.GameState;
import com.mojang.arcology.game.mob.Gender;
import com.mojang.arcology.game.mob.Player;
import com.mojang.arcology.game.mob.Player.Form;
import com.mojang.arcology.game.mob.Player.Job;

public class CharGenState extends State {
	private int row = 0;
	private int rowCount = 6;
	private Player player = new Player();

	private int hpMod = 0;
	private int strMod = 0;
	private int dexMod = 0;
	private int intMod = 0;

	private static final String LEGAL_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ���";

	public CharGenState() {
		this.updateMods();
	}

	public void display(Screen screen) {
		screen.clear();
		screen.drawStringCenter("Character generation", 3, 14);

		int yo = 8;
		screen.drawString("Name: " + player.name + (row == 0 ? "_" : ""), 4, yo + 0, (row == 0) ? 15 : 8);
		if (player.name.length() == 0 && row != 0) {
			screen.drawString("ANON", 10, yo + 0, 8);
		}
		screen.drawString("Gender: " + player.gender + (row == 1 ? " < >" : ""), 4, yo + 1, (row == 1) ? 15 : 8);
		screen.drawString("Form: " + player.form + (row == 2 ? " < >" : ""), 4, yo + 2, (row == 2) ? 15 : 8);
		screen.drawString("Job: " + player.job + (row == 3 ? " < >" : ""), 4, yo + 3, (row == 3) ? 15 : 8);
		screen.drawString("Reroll stats", 4, yo + 5, (row == 4) ? 15 : 8);
		screen.drawString("DONE!", 4, yo + 8, (row == 5) ? 15 : 8);

		screen.drawString(" HP:�f" + player.hp, 24, yo + 0, 7);
		screen.drawString("STR:�f" + player.str, 24, yo + 1, 7);
		screen.drawString("DEX:�f" + player.dex, 24, yo + 2, 7);
		screen.drawString("INT:�f" + player.iq, 24, yo + 3, 7);

		screen.drawString("GUN:�f" + player.iq, 24, yo + 5, 7);
		screen.drawString("MLE:�f" + player.str, 24, yo + 6, 7);
		screen.drawString("DEF:�f" + player.dex, 24, yo + 7, 7);
		screen.drawString("SPD:�f" + (100 + player.dex - 11), 24, yo + 8, 7);

		if (hpMod > 0) screen.drawString("+ " + hpMod, 24 + 8, yo + 0, 10);
		if (hpMod < 0) screen.drawString("- " + -hpMod, 24 + 8, yo + 0, 12);
		if (strMod > 0) screen.drawString("+ " + strMod, 24 + 8, yo + 1, 10);
		if (strMod < 0) screen.drawString("- " + -strMod, 24 + 8, yo + 1, 12);
		if (dexMod > 0) screen.drawString("+ " + dexMod, 24 + 8, yo + 2, 10);
		if (dexMod < 0) screen.drawString("- " + -dexMod, 24 + 8, yo + 2, 12);
		if (dexMod > 0) screen.drawString("+ " + dexMod, 24 + 8, yo + 8, 10);
		if (dexMod < 0) screen.drawString("- " + -dexMod, 24 + 8, yo + 8, 12);
		if (intMod > 0) screen.drawString("+ " + intMod, 24 + 8, yo + 3, 10);
		if (intMod < 0) screen.drawString("- " + -intMod, 24 + 8, yo + 3, 12);
		
		if (player.form==Form.Mutant)
		{
			screen.drawString("- 20%", 24 + 8, yo + 8, 12);
		}

		if (player.job==Job.Brawler)
		{
			screen.drawString("- 50%", 24 + 8, yo + 5, 12);
			screen.drawString("+ 100%", 24 + 8, yo + 6, 10);
		}

		if (player.job==Job.Marksman)
		{
			screen.drawString("+ 100%", 24 + 8, yo + 5, 10);
			screen.drawString("- 50%", 24 + 8, yo + 6, 12);
		}

		screen.drawString("----------------------------------------", 0, 20, 8);
		screen.drawString("----------------------------------------", 0, 25, 8);
		if (row == 0) {
			screen.drawString("The name of your character.", 3, 22, 7);
			screen.drawString("Has no impact on the game.", 3, 23, 7);
		}
		if (row == 1) {
			screen.drawString("The gender of your character.", 3, 22, 7);
			screen.drawString("Has no impact on the game.", 3, 23, 7);
		}
		if (row == 2) {
			if (player.form == Form.Human) {
				screen.drawString("Humans have no special powers", 3, 22, 7);
				screen.drawString("They can use all equipment", 3, 23, 7);
			}
			if (player.form == Form.Android) {
				screen.drawString("Androids heal very fast over", 3, 22, 7);
				screen.drawString("time, but can't eat food", 3, 23, 7);
			}
			if (player.form == Form.Mutant) {
				screen.drawString("Mutants have four arms, but", 3, 22, 7);
				screen.drawString("are slow", 3, 23, 7);
			}
		}
		if (row == 3) {
			if (player.job == Job.Soldier) {
				screen.drawString("Soldiers are equally good at", 3, 22, 7);
				screen.drawString("close and ranged combat.", 3, 23, 7);
			}
			if (player.job == Job.Brawler) {
				screen.drawString("Brawlers are experts at hand-to-", 3, 22, 7);
				screen.drawString("hand combat. Guns, not so much.", 3, 23, 7);
			}
			if (player.job == Job.Marksman) {
				screen.drawString("Marksmen are experts at guns,", 3, 22, 7);
				screen.drawString("but are weak fighters", 3, 23, 7);
			}
		}
		if (row == 4) {
			screen.drawString("Press space to reroll your stats", 3, 22, 7);
			screen.drawString("Press ? for more information", 3, 23, 7);
		}
		if (row == 5) {
			screen.drawString("Press space to start the game", 3, 22, 7);
			screen.drawString("Good luck.", 3, 23, 7);
		}
	}

	private void updateMods() {
		hpMod = 0;
		strMod = 0;
		dexMod = 0;
		intMod = 0;

		if (player.form == Form.Mutant) {
			strMod += 2;
			intMod -= 2;
		}
		if (player.form == Form.Android) {
			hpMod = -10;
			strMod += 2;
			dexMod += 2;
		}
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_ACTION) {
			if (row == 4) player.reroll();
			if (row == 5) {
				if (player.name.length() == 0) player.name = "ANON";
				player.hp += hpMod;
				player.hpMax += hpMod;
				player.str += strMod;
				player.dex += dexMod;
				player.iq += intMod;
				if (player.form == Form.Human) {
					player.color = 12;
					player.image = 32 * 5 + 0;
				}
				if (player.form == Form.Android) {
					player.color = 14;
					player.image = 32 * 5 + 1;
					player.healInterval = 1;
				}
				if (player.form == Form.Mutant) {
					player.color = 10;
					player.image = 32 * 5 + 2;
					player.armCount = 4;
				}

				if (player.job == Job.Soldier) {
					player.image += 0;
				}
				if (player.job == Job.Brawler) {
					player.image += 3;
				}
				if (player.job == Job.Marksman) {
					player.image += 6;
				}
				setState(new GameState(player));
			}
		}
		if (key == KEY_UP) {
			row--;
			if (row < 0) row = rowCount - 1;
		}
		if (key == KEY_DOWN) {
			row++;
			if (row >= rowCount) row = 0;
		}
		if (key == KEY_LEFT) {
			if (row == 1) swapGender();
			if (row == 2) setForm(player.form.ordinal() - 1);
			if (row == 3) setJob(player.job.ordinal() - 1);
		}
		if (key == KEY_RIGHT) {
			if (row == 1) swapGender();
			if (row == 2) setForm(player.form.ordinal() + 1);
			if (row == 3) setJob(player.job.ordinal() + 1);
		}
		if (key == KEY_BACK && player.name.length() > 0) {
			player.name = player.name.substring(0, player.name.length() - 1);
		}
	}

	public void swapGender() {
		player.gender = player.gender == Gender.male ? Gender.female : Gender.male;
	}

	public void setJob(int num) {
		if (num < 0) num = Player.Job.values().length - 1;
		if (num >= Player.Job.values().length) num = 0;
		player.job = Player.Job.values()[num];
		updateMods();
	}

	public void setForm(int num) {
		if (num < 0) num = Player.Form.values().length - 1;
		if (num >= Player.Form.values().length) num = 0;
		player.form = Player.Form.values()[num];
		updateMods();
	}

	public void keyTyped(String letter) {
		if (row != 0) return;
		if (LEGAL_CHARS.contains(letter) && player.name.length() < 8) {
			player.name += letter;
		}
	}
}
