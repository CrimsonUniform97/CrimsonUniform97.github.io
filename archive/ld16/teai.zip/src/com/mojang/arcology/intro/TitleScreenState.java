package com.mojang.arcology.intro;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;

public class TitleScreenState extends State {
	public void display(Screen screen) {
		screen.clear();
		screen.drawStringCenter("The Europa Arcology Incident", 7, 14);
		screen.drawStringCenter("by", 10, 8);
		screen.drawStringCenter("Mojang Specifications", 13, 14 - 8);
		screen.drawStringCenter("for Ludum Dare 16, 2009", 14, 8);
		screen.drawStringCenter("Press space to start", 20, 7);
		screen.drawStringCenter("(Press ? any time for help)", 21, 8);
/*
		for (int i = 0; i < EnemySpawner.templates.size(); i++) {
			EnemyTemplate t = EnemySpawner.templates.get(i);
			screen.set(2, 2 + i, t.img, t.col);
			screen.drawString(t.name, 4, 2 + i, 7);

		}*/
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_ACTION) {
			setState(new IntroTextState());
		}
	}
}