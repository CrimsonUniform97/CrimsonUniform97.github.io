package com.mojang.arcology;

public abstract class State {
	private Arcology arcology;
	
	protected static final int KEY_UP = 0;
	protected static final int KEY_DOWN = 1;
	protected static final int KEY_LEFT = 2;
	protected static final int KEY_RIGHT = 3;
	protected static final int KEY_UP_LEFT = 4;
	protected static final int KEY_DOWN_LEFT = 5;
	protected static final int KEY_UP_RIGHT = 6;
	protected static final int KEY_DOWN_RIGHT = 7;
	protected static final int KEY_ACTION = 8;
	protected static final int KEY_BACK = 9;

	public final void init(Arcology acrology) {
		// only initialize once.
		if (this.arcology != null)
			return;

		this.arcology = acrology;
		init();
	}

	protected void setState(State state) {
		arcology.setState(state);
	}

	public void pushState(State state) {
		arcology.pushState(state);
	}

	protected void popState() {
		arcology.popState();
	}

	protected void init() {
	}

	public void display(Screen screen) {
	}

	public void keyPressed(int key, boolean shifted) {
	}

	public void keyTyped(String keyChar) {
	}
}