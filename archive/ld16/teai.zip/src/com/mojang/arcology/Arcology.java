package com.mojang.arcology;

import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mojang.arcology.help.HelpState;
import com.mojang.arcology.intro.TitleScreenState;

public class Arcology extends Applet implements KeyListener, FocusListener {
	private static final long serialVersionUID = 1L;
	private Screen screen;
	private State state;
	private List<State> stateStack = new ArrayList<State>();
	private Map<Integer, Integer> keyMap = new HashMap<Integer, Integer>();

	public void init() {
		Image[][] fontSheet = new FontSheet("/sheet.png").getImages();
		screen = new Screen(getWidth() / 16, getHeight() / 16, fontSheet);

		keyMap.put(KeyEvent.VK_UP, State.KEY_UP);
		keyMap.put(KeyEvent.VK_DOWN, State.KEY_DOWN);
		keyMap.put(KeyEvent.VK_LEFT, State.KEY_LEFT);
		keyMap.put(KeyEvent.VK_RIGHT, State.KEY_RIGHT);
		keyMap.put(KeyEvent.VK_HOME, State.KEY_UP_LEFT);
		keyMap.put(KeyEvent.VK_END, State.KEY_DOWN_LEFT);
		keyMap.put(KeyEvent.VK_PAGE_UP, State.KEY_UP_RIGHT);
		keyMap.put(KeyEvent.VK_PAGE_DOWN, State.KEY_DOWN_RIGHT);

		keyMap.put(KeyEvent.VK_NUMPAD8, State.KEY_UP);
		keyMap.put(KeyEvent.VK_NUMPAD2, State.KEY_DOWN);
		keyMap.put(KeyEvent.VK_NUMPAD4, State.KEY_LEFT);
		keyMap.put(KeyEvent.VK_NUMPAD6, State.KEY_RIGHT);
		keyMap.put(KeyEvent.VK_NUMPAD7, State.KEY_UP_LEFT);
		keyMap.put(KeyEvent.VK_NUMPAD1, State.KEY_DOWN_LEFT);
		keyMap.put(KeyEvent.VK_NUMPAD9, State.KEY_UP_RIGHT);
		keyMap.put(KeyEvent.VK_NUMPAD3, State.KEY_DOWN_RIGHT);

		keyMap.put(KeyEvent.VK_SPACE, State.KEY_ACTION);
		keyMap.put(KeyEvent.VK_ENTER, State.KEY_ACTION);
		keyMap.put(KeyEvent.VK_ESCAPE, State.KEY_BACK);
		keyMap.put(KeyEvent.VK_BACK_SPACE, State.KEY_BACK);

		this.addKeyListener(this);
		this.addFocusListener(this);

		setState(new TitleScreenState());
	}

	public synchronized void setState(State state) {
		this.state = state;
		state.init(this);
		repaint();
	}

	public void pushState(State newState) {
		stateStack.add(state);
		setState(newState);
	}

	public void popState() {
		setState(stateStack.remove(stateStack.size() - 1));
	}

	public void update(Graphics g) {
		paint(g);
	}

	public synchronized void paint(Graphics g) {
		state.display(screen);
		g.drawImage(screen.getImage(), 0, 0, getWidth(), getHeight(), null);
	}

	public synchronized void keyPressed(KeyEvent e) {
		boolean shifted = e.isShiftDown() || e.isControlDown() || e.isAltDown() || e.isAltGraphDown();
		Integer key = keyMap.get(e.getKeyCode());
		if (key != null) {
			state.keyPressed(key, shifted);
		}
		repaint();
	}

	public void keyReleased(KeyEvent e) {
	}

	public synchronized void keyTyped(KeyEvent e) {
		if (e.getKeyChar() == '?') {
			if (!(state instanceof HelpState)) {
				pushState(new HelpState());
			}
		} else {
			state.keyTyped(("" + e.getKeyChar()).toUpperCase());
		}
		repaint();
	}

	public void focusGained(FocusEvent e) {
		screen.hasFocus = true;
		repaint();
	}

	public void focusLost(FocusEvent e) {
		screen.hasFocus = false;
		repaint();
	}
}
