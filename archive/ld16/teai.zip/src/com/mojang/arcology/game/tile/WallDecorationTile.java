package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;

public class WallDecorationTile extends Tile {
	public int getImage(Level level, int x, int y) {
		if (!level.isWall(x + 1, y) || !level.isWall(x - 1, y)) return 32 * 3+image;
		else return 32 * 2+image;
	}
}
