package com.mojang.arcology.game.mob;

public class EnemyTemplate {
	private static int diffCounter = 5;

	public final String name;
	public final int hp, atk, def, spd, img, col, xp;

	public EnemyTemplate(String name, int hp, int atk, int def, int spd, int img, int col) {
		this.name = name;
		this.hp = hp*diffCounter/100;
		
		this.atk = atk*diffCounter/100;
		this.def = def*diffCounter/100;
		
		this.spd = spd;
		
		this.img = img + 32 * 6;
		this.col = col;
		this.xp = diffCounter;
		
		diffCounter = diffCounter * 11 / 10 + 2;
	}

	public Enemy spawn(int x, int y) {
		return new Enemy(x, y, this);
	}
}