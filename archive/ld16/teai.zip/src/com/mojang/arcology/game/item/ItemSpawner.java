package com.mojang.arcology.game.item;

import java.util.Random;

public class ItemSpawner {
	private Random random = new Random();

	public Item spawnItem(int maxValue) {
		if (random.nextInt(4) == 0) {
			// Money!
			return new MoneyBag((random.nextInt(maxValue / 2) + maxValue / 2) / 4 + 1);
		} else if (random.nextInt(4) == 0) {
			// Ammo!
			return new Ammo(random.nextInt(8) + 1);
		} else if (random.nextInt(10) == 0) {
			return spawnKey(maxValue);
		} else if (random.nextInt(8) == 0) {
			return spawnFood(maxValue);
		} else if (random.nextInt(4) == 0) {
			// Armor!
			return spawnArmor(maxValue);
		} else if (random.nextInt(4) == 0) {
			// Weapon!
			int type = random.nextInt(2);

			if (type == 0) return spawnMelee(maxValue);
			if (type == 1) return spawnGun(maxValue);
		}
		return null;
	}

	private Item spawnArmor(int maxValue) {
		int type = random.nextInt(4);
		Equipment equipment = new Equipment();
		if (type == 0) {
			equipment.type = Equipment.HELMET;
			equipment.name = "helmet";
			equipment.image = 32 * 13 + 1;
		} else if (type == 1) {
			equipment.type = Equipment.ARMOR;
			equipment.name = "armor";
			equipment.image = 32 * 13 + 0;
		} else if (type == 2) {
			equipment.type = Equipment.PANTS;
			equipment.name = "pants";
			equipment.image = 32 * 13 + 2;
		} else if (type == 3) {
			equipment.type = Equipment.SHIELD;
			equipment.name = "shield";
			equipment.image = 32 * 13 + 3;
		}

		if (random.nextInt(4) == 0 && maxValue > 2000) {
			equipment.power = 25;
			equipment.value += 2000;
			equipment.weight = 50;
			equipment.color = 14;
			equipment.name = "Gold " + equipment.name; // Yes, this makes sense.
		} else if (random.nextInt(4) == 0 && maxValue > 500) {
			equipment.power = 15;
			equipment.value += 500;
			equipment.weight = 40;
			equipment.color = 15;
			equipment.name = "Steel " + equipment.name;
		} else if (random.nextInt(4) == 0 && maxValue > 50) {
			equipment.power = 10;
			equipment.value += 50;
			equipment.weight = 30;
			equipment.color = 8;
			equipment.name = "Kevlar " + equipment.name;
		} else {
			equipment.power = 5;
			equipment.value += 10;
			equipment.weight = 20;
			equipment.color = 4;
			equipment.name = "Leather " + equipment.name;
		}

		addPrefix(equipment, maxValue);
		addSuffix(equipment, maxValue);

		postFix(equipment);
		equipment.descriptions.add(0, "Def +" + equipment.power);

		return equipment;
	}

	private Item spawnKey(int maxValue) {
		return new Key(random.nextInt(3));
	}

	private Item spawnFood(int maxValue) {
		Food food = new Food(20);
		postFix(food);
		food.addDescription("Use to heal " + food.power + " damage");
		return food;
	}

	private Item spawnMelee(int maxValue) {
		Equipment equipment = new Equipment();
		equipment.type = Equipment.MELEE;

		if (random.nextInt(4) == 0 && maxValue > 2000) {
			equipment.power = 25;
			equipment.image = 32 * 10 + 3;
			equipment.value += 2000;
			equipment.weight = 50;
			equipment.name = "Chainsword";
		} else if (random.nextInt(4) == 0 && maxValue > 500) {
			equipment.power = 15;
			equipment.image = 32 * 10 + 2;
			equipment.value += 500;
			equipment.weight = 40;
			equipment.name = "Largesword";
		} else if (random.nextInt(4) == 0 && maxValue > 50) {
			equipment.power = 10;
			equipment.image = 32 * 10 + 1;
			equipment.value += 50;
			equipment.weight = 30;
			equipment.name = "Sword";
		} else {
			equipment.power = 5;
			equipment.image = 32 * 10;
			equipment.value += 10;
			equipment.weight = 20;
			equipment.name = "Knife";
		}

		addPrefix(equipment, maxValue);
		addSuffix(equipment, maxValue);
		postFix(equipment);
		equipment.descriptions.add(0, "MLE +" + equipment.power);

		return equipment;
	}

	private Item spawnGun(int maxValue) {
		Equipment equipment = new Equipment();
		equipment.type = Equipment.GUN;

		if (random.nextInt(4) == 0 && maxValue > 2000) {
			equipment.power = 25;
			equipment.image = 32 * 11 + 3;
			equipment.value += 2000;
			equipment.weight = 50;
			equipment.name = "Cannon";
			equipment.ammoRequirement = 8;
		} else if (random.nextInt(4) == 0 && maxValue > 500) {
			equipment.power = 15;
			equipment.image = 32 * 11 + 2;
			equipment.value += 500;
			equipment.weight = 40;
			equipment.name = "Zapper";
			equipment.ammoRequirement = 4;
		} else if (random.nextInt(4) == 0 && maxValue > 50) {
			equipment.power = 10;
			equipment.image = 32 * 11 + 1;
			equipment.value += 50;
			equipment.weight = 30;
			equipment.name = "Shotgun";
			equipment.ammoRequirement = 3;
		} else {
			equipment.power = 5;
			equipment.image = 32 * 11;
			equipment.value += 10;
			equipment.weight = 20;
			equipment.ammoRequirement = 1;
			equipment.name = "Pistol";
		}

		addPrefix(equipment, maxValue);
		addSuffix(equipment, maxValue);
		postFix(equipment);
		equipment.descriptions.add(0, "GUN +" + equipment.power);

		return equipment;
	}

	private void postFix(Item equipment) {
		equipment.value *= 5;
		int r = equipment.value / 4 + 1;
		equipment.value += random.nextInt(r) - random.nextInt(r);
		r = equipment.weight / 2 + 1;
		equipment.weight += random.nextInt(r) - random.nextInt(r);
		r = equipment.power / 2 + 1;
		equipment.power += random.nextInt(r) - random.nextInt(r);

		if (equipment.descriptions.size() > 0) {
			equipment.textColor = 3;
		}
	}

	private void addSuffix(Equipment equipment, int maxValue) {
		if (affordsAndRolls(equipment, 100, 600, maxValue)) {
			equipment.name = "Empowering " + equipment.name;
			equipment.strBonus = 2;
			equipment.addDescription("+2 str");
			equipment.color = 13;
			return;
		}
		if (affordsAndRolls(equipment, 100, 600, maxValue)) {
			equipment.name = "Quickening " + equipment.name;
			equipment.dexBonus = 2;
			equipment.addDescription("+2 dex");
			equipment.color = 13;
			return;
		}
		if (affordsAndRolls(equipment, 100, 600, maxValue)) {
			equipment.name = "Focusing " + equipment.name;
			equipment.intBonus = 2;
			equipment.addDescription("+2 int");
			return;
		}
		if (affordsAndRolls(equipment, 100, 600, maxValue)) {
			equipment.name = "Buffing " + equipment.name;
			equipment.hpBonus = 10;
			equipment.addDescription("+10% hp");
			equipment.color = 13;
			return;
		}
		if (affordsAndRolls(equipment, 100, 600, maxValue)) {
			equipment.name = "Tutoring " + equipment.name;
			equipment.xpBonus = 10;
			equipment.addDescription("+10% xp");
			equipment.color = 13;
			return;
		}
		if (affordsAndRolls(equipment, 200, 400, maxValue)) {
			equipment.name = "Mighty " + equipment.name;
			equipment.power += 6;
			equipment.power = equipment.power * 150 / 100;
			equipment.addDescription("+50% power");
			equipment.color = 12;
			return;
		}
		if (affordsAndRolls(equipment, 100, 150, maxValue)) {
			equipment.name = "Powerful " + equipment.name;
			equipment.power = equipment.power * 120 / 100;
			equipment.addDescription("+20% power");
			equipment.color = 12;
			return;
		}
		if (affordsAndRolls(equipment, 150, 50, maxValue)) {
			equipment.name = "Light " + equipment.name;
			equipment.weight /= 2;
			equipment.addDescription("-50% weight");
			equipment.color = 13;
			return;
		}
		if (affordsAndRolls(equipment, 10, 40, maxValue)) {
			equipment.name = "Rusty " + equipment.name;
			equipment.sellValue /= 3;
			equipment.power /= 2;
			equipment.addDescription("-50% power");
			equipment.color = 4;
			return;
		}
	}

	private void addPrefix(Equipment equipment, int maxValue) {
	}

	private boolean affordsAndRolls(Equipment item, int cost, int odds, int maxValue) {
		if (random.nextInt(odds / 4) != 0) return false;
		if ((item.value + cost) * cost / 100 <= maxValue) {
			item.value = (item.value + cost) * cost / 100;
			return true;
		}
		return false;
	}
}