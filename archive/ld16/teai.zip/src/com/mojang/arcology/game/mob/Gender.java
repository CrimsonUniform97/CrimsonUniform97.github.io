package com.mojang.arcology.game.mob;

public class Gender {
	
	public static Gender neuter = new Gender("neuter", "it", "it", "its");
	public static Gender male = new Gender("male", "he", "him", "his");
	public static Gender female = new Gender("female", "she", "her", "her");
	
	public final String name;
	public final String he;
	public final String him;
	public final String his;
	
	private Gender(String name, String he, String him, String his) {
		this.name = name;
		this.he = he;
		this.him = him;
		this.his = his;
	}
	
	public String toString()
	{
		return name;
	}
}
