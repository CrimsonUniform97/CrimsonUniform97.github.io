package com.mojang.arcology.game.mob;

public class Faction {
	
	public static Faction neutral = new Faction();
	public static Faction player = new Faction();
	public static Faction monster = new Faction();
	
	public boolean hates(Faction faction) {
		return faction!=this;
	}
}
