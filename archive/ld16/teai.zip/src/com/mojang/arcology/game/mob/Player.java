package com.mojang.arcology.game.mob;

import java.util.ArrayList;
import java.util.List;

import com.mojang.arcology.Dice;
import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.item.Equipment;
import com.mojang.arcology.game.item.Item;
import com.mojang.arcology.game.item.Key;

public class Player extends Mob {
	public static enum Form {
		Human, Mutant, Android
	}

	public static enum Job {
		Soldier, Brawler, Marksman
	}

	public Form form = Form.Human;
	public Job job = Job.Soldier;
	public int str;
	public int dex;
	public int iq;

	public int xp, xpNext;
	public int xpLevel;
	public int money = 0;
	public int ammo = 0;
	public List<Item> inventory = new ArrayList<Item>();
	public int armCount = 2;
	public Equipment[] equipment = new Equipment[7];

	public Player() {
		reroll();
		xpLevel = 1;
		xp = 0;
		xpNext = 200;
		image = 32 * 5;
		color = 14;
		faction = Faction.player;
		name = "";
		gender = Gender.male;
	}

	public void setLevel(Level level) {
		super.setLevel(level);
		level.player = this;
	}

	public void tick() {
		super.tick();
	}

	public void reroll() {
		str = Dice.roll(6, 3);
		dex = Dice.roll(6, 3);
		iq = Dice.roll(6, 3);
		hpMax = hp = Dice.roll(6, 3) + 10;
	}

	public String getName() {
		return "you";
	}

	public void kill(Mob mob) {
		int xp = mob.xpReward;
		int r = xp/2+1;
		xp+=random.nextInt(r)-random.nextInt(r);
		addXp(xp);
	}

	private void addXp(int xpToAdd) {
		xp += xpToAdd;
		if (xp >= xpNext) {
			xp = xpNext;
		}
	}

	public String levelUp() {
		xp = 0;
		xpNext = xpNext * 125 / 100 + 100;
		xpLevel++;
		int hpAdd = Dice.roll(6, 3);
		if (form == Form.Android) {
			hpAdd = hpAdd * 8 / 10;
		}
		hpMax += hpAdd;
		hp += hpAdd;

		int strAdd = random.nextInt(3) / 2;
		int dexAdd = random.nextInt(3) / 2;
		int intAdd = random.nextInt(3) / 2;
		String levelUpMsg = "HP+" + hpAdd;

		if (strAdd > 0) {
			levelUpMsg += ", str+1";
			str += strAdd;
		}
		if (dexAdd > 0) {
			levelUpMsg += ", dex+1";
			dex += dexAdd;
		}
		if (intAdd > 0) {
			levelUpMsg += ", int+1";
			iq += intAdd;
		}
		return levelUpMsg;
	}

	public Key getKey(int lockColor) {
		for (int i = 0; i < inventory.size(); i++) {
			Item item = inventory.get(i);
			if (item instanceof Key) {
				if (((Key) item).keyColor == lockColor) return (Key) item;
			}

		}
		return null;
	}

	public int findEquipmentSlotFor(Item item) {
		if (!(item instanceof Equipment)) return -1;
		Equipment e = (Equipment) item;
		if (e.type == Equipment.GUN || e.type == Equipment.MELEE || e.type == Equipment.SHIELD) {
			for (int i = 0; i < armCount; i++) {
				if (equipment[i + 3] == null) return i + 3;
			}
		}
		if (e.type == Equipment.HELMET && equipment[0] == null) return 0;
		if (e.type == Equipment.ARMOR && equipment[1] == null) return 1;
		if (e.type == Equipment.PANTS && equipment[2] == null) return 2;
		return -1;
	}

	public int getStr() {
		int value = str;
		for (int i = 0; i < equipment.length; i++) {
			Equipment e = equipment[i];
			if (e != null) value += e.strBonus;
		}
		return value;
	}

	public int getInt() {
		int value = iq;
		for (int i = 0; i < equipment.length; i++) {
			Equipment e = equipment[i];
			if (e != null) value += e.intBonus;
		}
		return value;
	}

	public int getDex() {
		int value = dex;
		for (int i = 0; i < equipment.length; i++) {
			Equipment e = equipment[i];
			if (e != null) value += e.dexBonus;
		}
		return value;
	}

	public int getSpeed() {
		int value = 100 + getDex() - 11;
		for (int i = 0; i < equipment.length; i++) {
			Equipment e = equipment[i];
			if (e != null) value += e.speedBonus;
		}
		if (form == Form.Mutant) {
			value = value * 8 / 10;
		}
		return value;
	}

	public int getMelee() {
		int value = str;
		for (int i = 0; i < equipment.length; i++) {
			Equipment e = equipment[i];
			if (e != null && e.type == Equipment.MELEE) value += e.power;
		}
		if (job == Job.Brawler) {
			value *= 2;
		}
		if (job == Job.Marksman) {
			value /= 2;
		}
		return value;
	}

	public int getAtk() {
		int value = iq;
		for (int i = 0; i < equipment.length; i++) {
			Equipment e = equipment[i];
			if (e != null && e.type == Equipment.GUN) value += e.power;
		}
		if (job == Job.Brawler) {
			value /= 2;
		}
		if (job == Job.Marksman) {
			value *= 2;
		}
		return value;
	}

	public int getDef() {
		int value = dex;
		for (int i = 0; i < equipment.length; i++) {
			Equipment e = equipment[i];
			if (e != null && isArmor(e)) value += e.power;
		}
		return value;
	}

	private boolean isArmor(Equipment e) {
		if (e.type == Equipment.HELMET) return true;
		if (e.type == Equipment.ARMOR) return true;
		if (e.type == Equipment.PANTS) return true;
		if (e.type == Equipment.SHIELD) return true;
		return false;
	}

	public String getStrString() {
		int v = getStr();
		if (v > str) return "�a" + v;
		if (v < str) return "�4" + v;
		return "" + v;
	}

	public String getIntString() {
		int v = getInt();
		if (v > iq) return "�a" + v;
		if (v < iq) return "�4" + v;
		return "" + v;
	}

	public String getDexString() {
		int v = getDex();
		if (v > dex) return "�a" + v;
		if (v < dex) return "�4" + v;
		return "" + v;
	}

	public boolean isOverBurdened() {
		int totalCarried = 0;
		for (int i = 0; i < inventory.size(); i++) {
			totalCarried += inventory.get(i).weight;
		}
		return totalCarried > getStr() * 10;
	}
}