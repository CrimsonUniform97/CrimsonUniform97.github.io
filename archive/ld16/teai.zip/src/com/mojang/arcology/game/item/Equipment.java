package com.mojang.arcology.game.item;

public class Equipment extends Item {
	public static final int MELEE = 0;
	public static final int GUN = 1;

	public static final int HELMET = 2;
	public static final int ARMOR = 3;
	public static final int PANTS = 4;
	public static final int SHIELD = 5;

	public int type;
	public int sellValue = 100;

	public int strBonus;
	public int dexBonus;
	public int intBonus;
	public int hpBonus;
	public int xpBonus;
	public int speedBonus;
	public int ammoRequirement = 0;

	public Equipment() {
	}

	public int getSellValue() {
		return super.getSellValue() * sellValue / 100;
	}

	public int getBuyValue() {
		return super.getBuyValue() * sellValue / 100;
	}
}