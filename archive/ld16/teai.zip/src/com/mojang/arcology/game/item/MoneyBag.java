package com.mojang.arcology.game.item;

public class MoneyBag extends Item {
	public MoneyBag(int value) {
		this.value = value;
		color = 14;
		image = 32 * 9;
		name = "$"+value;
	}
}