package com.mojang.arcology.game.mob;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EnemySpawner {
	private static final int BLOB = 0;
	private static final int RAT = 1;
	private static final int DROID = 2;
	private static final int ROBOT = 3;
	private static final int BAT = 4;
	private static final int HUMAN = 5;
	private static final int SPIDER = 6;

	public static List<EnemyTemplate> templates = new ArrayList<EnemyTemplate>();
	private Random random = new Random();

	static {
		// name hp atk def spd img col
		templates.add(new EnemyTemplate("RAT", 100, 100, 100, 140, RAT, 12));
		templates.add(new EnemyTemplate("SLIME", 150, 60, 160, 50, BLOB, 10));
		templates.add(new EnemyTemplate("SPIDER", 50, 130, 80, 130, SPIDER, 8));
		templates.add(new EnemyTemplate("BAT", 20, 70, 100, 110, BAT, 7));
		templates.add(new EnemyTemplate("OOZE", 150, 60, 160, 50, BLOB, 8));
		templates.add(new EnemyTemplate("DROID", 70, 60, 130, 100, DROID, 11));
		templates.add(new EnemyTemplate("DOG", 100, 100, 100, 140, RAT, 7));
		templates.add(new EnemyTemplate("GOOP", 150, 60, 160, 50, BLOB, 12));
		templates.add(new EnemyTemplate("LEECHER", 20, 70, 100, 110, BAT, 10));
		templates.add(new EnemyTemplate("ZAPPER", 70, 60, 130, 100, DROID, 14));
		templates.add(new EnemyTemplate("GRUNT", 200, 150, 50, 80, ROBOT, 12));
		templates.add(new EnemyTemplate("MERC", 150, 100, 100, 100, HUMAN, 12));
		templates.add(new EnemyTemplate("QUEEN", 50, 130, 80, 130, SPIDER, 11));
		templates.add(new EnemyTemplate("THUG", 200, 150, 50, 80, ROBOT, 9));
		templates.add(new EnemyTemplate("MELTER", 150, 60, 160, 50, BLOB, 15));
		templates.add(new EnemyTemplate("SOLDIER", 150, 100, 100, 100, HUMAN, 12));
		templates.add(new EnemyTemplate("WOLF", 100, 100, 100, 140, RAT, 15));
		templates.add(new EnemyTemplate("BRUTE", 200, 150, 50, 80, ROBOT, 10));
		templates.add(new EnemyTemplate("FEEDER", 50, 130, 80, 130, SPIDER, 7));
	}

	public EnemySpawner() {
		for (int i = 1; i < 17; i++)
			spawn(i, 0, 0);
	}

	public Enemy spawn(int depth, int x, int y) {
		int range = templates.size() / 8 + 1+depth/7;
		int offs = (templates.size() - range) * (depth - 1) / 15;
		int slot = offs + random.nextInt(range);
		return templates.get(slot).spawn(x, y);
	}
}