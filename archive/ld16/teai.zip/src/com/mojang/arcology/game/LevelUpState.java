package com.mojang.arcology.game;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.game.mob.Player;

public class LevelUpState extends State {
	private Player player;
	private String levelUpMsg;

	public LevelUpState(Player player, String levelUpMsg) {
		this.player = player;
		this.levelUpMsg = levelUpMsg;
	}

	public void display(Screen screen) {
		screen.clear(0, 12, 40, 18);

		screen.drawString("gameovergameovergameovergameovergameover", 0, 11, 32);
		screen.drawString("meovergameovergameovergameovergameoverga", 0, 18, 32);
		
		screen.drawString("leveluplevelupleveluplevelupleveluplevel", 0, 12, 8+16);
		screen.drawString("veluplevelupleveluplevelupleveluplevelup", 0, 17, 8+16);
		screen.drawStringCenter("LEVEL UP TO "+player.xpLevel, 14, 14);
		screen.drawStringCenter(levelUpMsg, 15, 15);
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_ACTION || key == KEY_BACK) {
			popState();
		}
	}
}
