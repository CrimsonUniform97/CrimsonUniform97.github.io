package com.mojang.arcology.game.item;

public class Ammo extends Item {
	public Ammo(int value) {
		this.value = value;
		color = 14;
		image = 32 * 12;
		name = ""+value+" ammo";
	}
}