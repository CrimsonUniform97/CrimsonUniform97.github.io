package com.mojang.arcology.game.mob;

public class Enemy extends Mob {
	private Mob target;

	public int melee, gun, def, speed;
	private int unseenTicks;

	public Enemy(int x, int y, EnemyTemplate template) {
		this.x = x;
		this.y = y;
		image = template.img;
		color = template.col;
		hp = hpMax = template.hp;
		faction = Faction.monster;
		name = template.name;

		melee = template.atk;
		gun = 0;
		def = template.def;
		speed = template.spd;
		xpReward = template.xp;
	}

	public void tick() {
		super.tick();

		if (level.isVisible(x, y)) {
			target = level.player;
			unseenTicks = 0;
		} else {
			unseenTicks++;
			if (unseenTicks == 100) {
				super.die();
				return;
			}
		}

		int xa = random.nextInt(3) - 1;
		int ya = random.nextInt(3) - 1;
		if (target != null) {
			xa = Integer.signum(target.x - x);
			ya = Integer.signum(target.y - y);

			if (level.isSolid(x + xa, y + ya)) {
				if (!level.isSolid(x + xa, y)) {
					ya = 0;
				} else if (!level.isSolid(x, y + ya)) {
					xa = 0;
				}
			}
		}

		this.attemptMove(xa, ya);
	}

	public void die() {
		super.die();
		level.dropLoot(x, y);
	}

	public int getAtk() {
		return gun;
	}

	public int getDef() {
		return def;
	}

	public int getMelee() {
		return melee;
	}

	public int getSpeed() {
		return speed;
	}
}
