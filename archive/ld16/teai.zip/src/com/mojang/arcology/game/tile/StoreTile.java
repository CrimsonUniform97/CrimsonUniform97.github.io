package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.mob.Mob;
import com.mojang.arcology.game.mob.Player;

public class StoreTile extends WallDecorationTile {
	public boolean tryMove(Level level, int x, int y, Mob mob) {
		if (!isSolid) return true;

		if (mob instanceof Player) {
			Player player = (Player) mob;
			level.pushState(new StoreState(player, level.storeItems));
		}
		return !isSolid;
	}
}
