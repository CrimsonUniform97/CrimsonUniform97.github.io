package com.mojang.arcology.game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.game.item.Ammo;
import com.mojang.arcology.game.item.Item;
import com.mojang.arcology.game.item.ItemSpawner;
import com.mojang.arcology.game.item.Key;
import com.mojang.arcology.game.item.MoneyBag;
import com.mojang.arcology.game.mob.EnemySpawner;
import com.mojang.arcology.game.mob.Mob;
import com.mojang.arcology.game.mob.Player;
import com.mojang.arcology.game.tile.StairsTile;
import com.mojang.arcology.game.tile.Tile;

public class Level {
	private int width, height;
	private Tile[] tiles;
	private Tile[] effects;
	private int[] seen;
	private Random random = new Random();

	private Mob[] tileMobs;
	private List<Item>[] tileItems;
	private List<Mob> mobs = new ArrayList<Mob>();
	public Player player;
	private GameState gameState;
	private ItemSpawner itemSpawner = new ItemSpawner();
	private EnemySpawner enemySpawner = new EnemySpawner();
	public int depth;
	private int maxMobs = 0;
	protected double currentMoveTime = 0;
	private int maxStores = 2;
	private int maxLevelStations = 2;
	public Pos spawnPos;

	private Comparator<Mob> mobSpeedSorter = new Comparator<Mob>() {
		public int compare(final Mob a, final Mob b) {
			if (a.nextMoveTime < b.nextMoveTime) return -1;
			if (a.nextMoveTime > b.nextMoveTime) return +1;
			return 0;
		}
	};

	public List<Item> storeItems = new ArrayList<Item>();

	@SuppressWarnings("unchecked")
	public Level(GameState gameState, int width, int height, int depth) {
		this.depth = depth;
		this.gameState = gameState;
		this.width = width;
		this.height = height;

		tiles = new Tile[width * height];
		effects = new Tile[width * height];
		tileMobs = new Mob[width * height];
		tileItems = new List[width * height];
		seen = new int[width * height];
		for (int i = 0; i < tiles.length; i++) {
			tiles[i] = Tile.wall;
			tileItems[i] = new ArrayList<Item>();
		}

		for (int i = 0; i < width * height; i++) {
			addRoom(i > 0);
		}

		for (int i = 0; i < width * height / 10; i++) {
			addDoor();
		}

		Pos[] posPair = generateDistantPosPair();
		if (depth > 1) {
			Pos p = posPair[0];
			setTile(p.x, p.y, Tile.stairsDown);
		} else {
			spawnPos = posPair[0];
		}

		if (depth < 16) {
			Pos p = posPair[1];
			setTile(p.x, p.y, Tile.stairsUp);
		} else {
			Pos p = posPair[1];
			setTile(p.x, p.y, Tile.beacon);
		}

		for (int i = 0; i < width * height / 100; i++) {
			addObject();
		}

		maxStores = width * height / 500;
		maxLevelStations = width * height / 500;

		for (int i = 0; i < width * height * 50; i++) {
			addStation();
			if (maxStores == 0 && maxLevelStations == 0) break;
		}

		maxMobs = width * height / 50;

		for (int i = 0; i < width * height / 200; i++) {
			int xo = random.nextInt(width);
			int yo = random.nextInt(height);
			int count = random.nextInt(9) + 1;
			for (int j = 0; j < count; j++) {
				int r = 4;
				int x = xo + random.nextInt(r) - random.nextInt(r);
				int y = yo + random.nextInt(r) - random.nextInt(r);
				if (getTile(x, y) == Tile.floor) {
					Item item = itemSpawner.spawnItem(random.nextInt(getMaxValue() / 2) + getMaxValue() / 2);
					if (item != null) {
						addItem(item, x, y);
					}
				}
			}
		}

		for (int i = 0; i < 200; i++) {
			Item item = itemSpawner.spawnItem(getMaxValue() * 2);
			if (item != null) {
				if (item instanceof MoneyBag) continue;
				if (item instanceof Ammo) continue;
				if (item instanceof Key) continue;
				storeItems.add(item);
			}
		}

		Collections.sort(storeItems, new Comparator<Item>() {
			public int compare(Item a, Item b) {
				if (a.getBuyValue() > b.getBuyValue()) return -1;
				if (a.getBuyValue() < b.getBuyValue()) return 1;
				return 0;
			}
		});

		int storeCount = random.nextInt(30) + 10;
		while (storeItems.size() > storeCount) {
			storeItems.remove(storeItems.size() - 1);
		}
	}

	private Pos[] generateDistantPosPair() {
		Pos[] best = new Pos[2];
		int bestDist = 0;
		for (int i = 0; i < 10; i++) {
			Pos p0 = getRandomWallPos();
			Pos p1 = getRandomWallPos();

			int dist = p0.distanceTo(p1);
			if (dist >= bestDist) {
				best[0] = p0;
				best[1] = p1;
				bestDist = dist;
			}
		}
		return best;
	}

	private void addStation() {
		int x = random.nextInt(width - 2) + 1;
		int y = random.nextInt(height - 2) + 1;

		if (getTile(x, y) == Tile.wall) {
			int wallCount = 0;
			if (getTile(x, y - 1) == Tile.wall) wallCount++;
			if (getTile(x, y + 1) == Tile.wall) wallCount++;
			if (getTile(x - 1, y) == Tile.wall) wallCount++;
			if (getTile(x + 1, y) == Tile.wall) wallCount++;

			int freeCount = 0;
			// if (getTile(x, y - 1) == Tile.floor) freeCount++;
			if (getTile(x, y + 1) == Tile.floor) freeCount++;
			// if (getTile(x - 1, y) == Tile.floor) freeCount++;
			if (getTile(x + 1, y) == Tile.floor) freeCount++;

			if (wallCount == 3 && freeCount == 1) {
				if (random.nextInt(2) == 0 && maxStores > 0) {
					maxStores--;
					setTile(x, y, Tile.store);
				} else if (maxLevelStations > 0) {
					maxLevelStations--;
					setTile(x, y, Tile.levelUp);
				}
			}
		}
	}

	private Pos getRandomWallPos() {
		int maxTicks = 10000;
		while (true) {
			if (maxTicks-- == 0) throw new RuntimeException("Too many iterations, aborting!");
			int x = random.nextInt(width - 2) + 1;
			int y = random.nextInt(height - 2) + 1;

			int wallCount = 0;
			if (isWall(x, y - 1)) wallCount++;
			if (isWall(x, y + 1)) wallCount++;
			if (isWall(x - 1, y)) wallCount++;
			if (isWall(x + 1, y)) wallCount++;
			int cornerCount = 0;
			if (isWall(x - 1, y - 1)) cornerCount++;
			if (isWall(x + 1, y - 1)) cornerCount++;
			if (isWall(x + 1, y + 1)) cornerCount++;
			if (isWall(x - 1, y + 1)) cornerCount++;
			if (wallCount == 1 && cornerCount == 2) {
				return new Pos(x, y);
			}
		}
	}

	private void addObject() {
		int x = random.nextInt(width - 2) + 1;
		int y = random.nextInt(height - 2) + 1;

		if (getTile(x, y) != Tile.floor) return;

		int wallCount = 0;
		if (isWall(x, y - 1)) wallCount++;
		if (isWall(x, y + 1)) wallCount++;
		if (isWall(x - 1, y)) wallCount++;
		if (isWall(x + 1, y)) wallCount++;
		int cornerCount = 0;
		if (isWall(x - 1, y - 1)) cornerCount++;
		if (isWall(x + 1, y - 1)) cornerCount++;
		if (isWall(x + 1, y + 1)) cornerCount++;
		if (isWall(x - 1, y + 1)) cornerCount++;
		if (wallCount != 1 || cornerCount != 2) return;

		if (random.nextInt(20) == 0) setTile(x, y, Tile.largeChest);
		else if (random.nextInt(5) == 0) setTile(x, y, Tile.mediumChest);
		else setTile(x, y, Tile.smallChest);
	}

	private int getMaxValue() {
		return (depth * depth + depth * 8);
	}

	private void tryAddMob() {
		int xo = random.nextInt(width);
		int yo = random.nextInt(height);
		int count = random.nextInt(6) + 1;

		for (int i = 0; i < count; i++) {
			int x = xo + random.nextInt(4) - random.nextInt(4);
			int y = yo + random.nextInt(4) - random.nextInt(4);

			if (mobs.size() < maxMobs) {
				if (isFree(x, y) && !isVisible(x, y)) {
					addMob(enemySpawner.spawn(depth, x, y));
				}
			}
		}
	}

	public void moveMob(Mob mob, int x, int y) {
		if (tileMobs[mob.x + mob.y * width] != mob) {
			throw new RuntimeException("Mob wasn't there!");
		}
		if (tileMobs[x + y * width] != null) {
			throw new RuntimeException("Tile wasn't empty!!");
		}

		tileMobs[mob.x + mob.y * width] = null;
		tileMobs[x + y * width] = mob;
	}

	public void addMob(Mob mob) {
		if (mobs.contains(mob)) return;
		mob.nextMoveTime = currentMoveTime + 1.0 / mob.getSpeed();
		mobs.add(mob);
		mob.setLevel(this);
		if (tileMobs[mob.x + mob.y * width] != null) {
			System.out.println("Pos: " + mob.x + ", " + mob.y);
			System.out.println("Existing: " + tileMobs[mob.x + mob.y * width]);
			System.out.println("New: " + mob);
			throw new RuntimeException("Mob already exists!!");
		}
		tileMobs[mob.x + mob.y * width] = mob;
	}

	public void removeMob(Mob mob) {
		mobs.remove(mob);
		if (tileMobs[mob.x + mob.y * width] != mob) {
			System.out.println("Pos: " + mob.x + ", " + mob.y);
			System.out.println("Missing: " + mob);
			throw new RuntimeException("Mob doesn't exist!");
		}
		tileMobs[mob.x + mob.y * width] = null;
	}

	public void addItem(Item item, int x, int y) {
		tileItems[x + y * width].add(item);
	}

	public void removeItem(Item item, int x, int y) {
		tileItems[x + y * width].remove(item);
	}

	private void addRoom(boolean check) {
		int w = random.nextInt(12) + 4;
		int h = random.nextInt(12) + 4;

		if (random.nextInt(4) > 0) {
			w = random.nextInt(4) + 4;
			h = random.nextInt(4) + 4;
			if (random.nextBoolean()) w = 1;
			else h = 1;
		}

		w = w / 4 * 4 + 1;
		h = h / 4 * 4 + 1;
		int x = random.nextInt(width - w - 2) + 1;
		int y = random.nextInt(height - h - 2) + 1;
		x = x / 4 * 4 + 1;
		y = y / 4 * 4 + 1;

		if (check) {
			int overlap = 0;
			for (int xx = x - 1; xx < x + w + 1; xx++)
				for (int yy = y - 1; yy < y + h + 1; yy++) {
					if (tiles[xx + yy * width] == Tile.floor) overlap++;
				}
			if (overlap < 2 || overlap > 4) return;
		}
		for (int xx = x; xx < x + w; xx++)
			for (int yy = y; yy < y + h; yy++) {
				tiles[xx + yy * width] = Tile.floor;
			}
	}

	private void addDoor() {
		int x = random.nextInt(width - 2) + 1;
		int y = random.nextInt(height - 2) + 1;

		boolean u = isWall(x, y - 1);
		boolean d = isWall(x, y + 1);
		boolean l = isWall(x - 1, y);
		boolean r = isWall(x + 1, y);

		if (u == d && l == r && u != r) {
			int cornerCount = 0;
			if (isSolid(x - 1, y - 1)) cornerCount++;
			if (isSolid(x + 1, y - 1)) cornerCount++;
			if (isSolid(x + 1, y + 1)) cornerCount++;
			if (isSolid(x - 1, y + 1)) cornerCount++;
			if (cornerCount < 4) {
				if (depth > 1 && random.nextInt(3) == 0) {
					int col = random.nextInt(3);
					if (col == 0) tiles[x + y * width] = Tile.blueDoor;
					if (col == 1) tiles[x + y * width] = Tile.greenDoor;
					if (col == 2) tiles[x + y * width] = Tile.redDoor;
				} else {
					tiles[x + y * width] = Tile.door;
				}
			}
		}
	}

	public void display(Screen screen, int x0, int y0, int x1, int y1, int xo, int yo) {
		xo -= (x1 - x0) / 2;
		yo -= (y1 - y0) / 2;

		if (xo > width - (x1 - x0)) xo = width - (x1 - x0);
		if (yo > height - (y1 - y0)) yo = height - (y1 - y0);
		if (xo < 0) xo = 0;
		if (yo < 0) yo = 0;

		xo -= x0;
		yo -= y0;

		for (int x = x0 + xo; x < x1 + xo; x++) {
			for (int y = y0 + yo; y < y1 + yo; y++) {
				if (x >= width || y >= height) continue;
				int seenLevel = seen[x + y * width];
				if (seenLevel == 0) {
					screen.set(x - xo, y - yo, (x + y * width) % 1024, 32);
					continue;
				}

				int dark = seenLevel == 1 ? 16 : 0;
				Tile tile = tiles[x + y * width];
				int image = tile.getImage(this, x, y);
				int color = tile.getColor(this, x, y);
				if (seenLevel == 2 && effects[x + y * width] != null) {
					image = effects[x + y * width].getImage(this, x, y);
					color = effects[x + y * width].getColor(this, x, y);
				} else {

					if (seenLevel == 2 && tileMobs[x + y * width] != null) {
						Mob mob = tileMobs[x + y * width];
						image = mob.getImage();
						color = mob.getColor();
					} else if (tileItems[x + y * width].size() > 0) {
						Item item = tileItems[x + y * width].get(tileItems[x + y * width].size() - 1);
						image = item.getImage();
						color = item.getColor();
					}
				}

				screen.set(x - xo, y - yo, image, color + dark);
			}
		}

		for (int i = 0; i < effects.length; i++) {
			effects[i] = null;
		}
	}

	public void lightup(int xp, int yp, int r) {
		for (int x = xp - r; x <= xp + r; x++) {
			lightRay(xp, yp, x, yp - r, r);
			lightRay(xp, yp, x, yp + r, r);

		}
		for (int y = yp - r; y <= yp + r; y++) {
			lightRay(xp, yp, xp - r, y, r);
			lightRay(xp, yp, xp + r, y, r);
		}
	}

	private void lightRay(int x0, int y0, int x1, int y1, int r) {
		int rd = r;
		{
			double xd = x1 - x0;
			double yd = y1 - y0;
			double dist = Math.sqrt(xd * xd + yd * yd) / r;
			rd = (int) (r / dist);
		}

		for (int i = 0; i <= rd; i++) {
			int x = x0 + (x1 - x0) * i / r;
			int y = y0 + (y1 - y0) * i / r;
			if (isSolid(x, y)) {
				return;

			}
			int xa = x - x0;
			int ya = y - y0;

			for (int xx = -1; xx <= 1; xx++) {
				if (xx == -1 && xa > 0) continue;
				if (xx == +1 && xa < 0) continue;
				for (int yy = -1; yy <= 1; yy++) {
					if (yy == -1 && ya > 0) continue;
					if (yy == +1 && ya < 0) continue;
					light(x + xx, y + yy);
				}
			}
		}
	}

	private void light(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return;
		seen[x + y * width] = 2;
	}

	public Tile getTile(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return Tile.wall;
		return tiles[x + y * width];
	}

	public Mob getMob(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return null;
		return tileMobs[x + y * width];
	}

	public boolean isSolid(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return false;
		return tiles[x + y * width].isSolid;
	}

	public boolean isFree(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return false;
		return (!isSolid(x, y) && tileMobs[x + y * width] == null);
	}

	public boolean isWall(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return false;
		return tiles[x + y * width].isWall;
	}

	public void setTile(int x, int y, Tile tile) {
		if (x < 0 || y < 0 || x >= width || y >= height) return;
		tiles[x + y * width] = tile;
	}

	public boolean isSeen(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return false;
		return seen[x + y * width] > 0;
	}

	public boolean isVisible(int x, int y) {
		if (x < 0 || y < 0 || x >= width || y >= height) return false;
		return seen[x + y * width] == 2;
	}

	public Pos getRandomFreePos() {
		int maxTicks = 10000;
		while (true) {
			if (maxTicks-- == 0) throw new RuntimeException("Too many iterations, aborting!");
			int x = random.nextInt(width);
			int y = random.nextInt(height);
			if (isFree(x, y)) {
				return new Pos(x, y);
			}
		}
	}

	public void resetLights() {
		for (int i = 0; i < width * height; i++) {
			if (seen[i] == 2) seen[i] = 1;
		}
	}

	public boolean tryMove(Mob mob, int x, int y) {
		Mob target = getMob(x, y);
		if (target != null) {
			return target.tryMove(mob);
		}

		if (getTile(x, y).tryMove(this, x, y, mob)) {
			if (mob == player) {
				playerStep(x, y);
			}
			return true;
		}
		return false;
	}

	private void playerStep(int x, int y) {
		int totalMoney = 0;
		int totalAmmo = 0;
		List<Item> items = tileItems[x + y * width];
		for (int i = 0; i < items.size(); i++) {
			Item item = items.get(i);
			if (item instanceof MoneyBag) {
				items.remove(i--);
				totalMoney += item.value;
			}
			if (item instanceof Ammo) {
				items.remove(i--);
				totalAmmo += item.value;
			}
		}
		if (totalMoney > 0) {
			addMessage("You get �e$" + totalMoney);
			player.money += totalMoney;
		}
		if (totalAmmo > 0) {
			addMessage("You get �e" + totalAmmo + "�7 ammo");
			player.ammo += totalAmmo;
		}

		if (items.size() == 1) {
			addMessage("There's a �f" + items.get(0).name + "�7 here");
		} else if (items.size() > 1) {
			addMessage("There are �f" + items.size() + " items �7here");
		}
	}

	public void tick() {
		tryAddMob();

		int maxTicks = 10000;

		while (true) {
			if (player.isDead) return;
			if (mobs.size() == 0) return;
			if (maxTicks-- == 0) throw new RuntimeException("Whoa, failed to finish processing mobs");

			Collections.sort(mobs, mobSpeedSorter);
			Mob mob = mobs.get(0);
			if (mob == player) return;

			mob.tick();
			currentMoveTime = mob.nextMoveTime;
			mob.nextMoveTime += 1.0 / mob.getSpeed();
		}
	}

	public void addMessage(String string) {
		gameState.addMessage(string);
	}

	public void addActionMessage(Mob mob, String playerMsg, String monsterMsg) {
		if (mob == player) {
			addMessage("you " + playerMsg);
		} else {
			addMessage(mob.getName() + " " + monsterMsg);
		}
	}

	public int dropLoot(int x, int y) {
		int levelValue = getMaxValue();
		int count = 0;
		for (int i = 0; i < 2; i++) {
			Item item = itemSpawner.spawnItem(levelValue);
			if (item != null) {
				count++;
				addItem(item, x, y);
			}
		}
		return count;
	}

	public List<Item> getItems(int x, int y) {
		return tileItems[x + y * width];
	}

	public void setEffect(int x, int y, Tile tile) {
		if (x < 0 || y < 0 || x >= width || y >= height) return;
		effects[x + y * width] = tile;
	}

	public void pushState(State state) {
		gameState.pushState(state);
	}

	public void travelStairs(int dir) {
		gameState.travelToFloor(depth + dir, dir);
	}

	public Pos findStairs(int dir) {
		for (int i = 0; i < width * height; i++) {
			if (tiles[i] instanceof StairsTile) {
				StairsTile stairs = (StairsTile) tiles[i];
				if (stairs.dir == dir) return new Pos(i % width, i / width);
			}
		}
		return null;
	}

	public void winGame() {
		gameState.winGame();
	}
}