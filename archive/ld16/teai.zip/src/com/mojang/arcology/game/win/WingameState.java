package com.mojang.arcology.game.win;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.intro.TitleScreenState;

public class WingameState extends State {
	private BufferedReader br;
	private boolean done = false;
	private String[] lines = new String[30];

	public WingameState() {
		readNext();
	}

	public void readNext() {
		for (int i = 0; i < 30; i++) {
			lines[i] = "";
		}
		if (br == null) {
			br = new BufferedReader(new InputStreamReader(WingameState.class.getResourceAsStream("wingame.txt")));
		}
		String line = "";
		int row = 3;
		try {

			while ((line = br.readLine()) != null) {
				if (line.startsWith("-")) {
					break;
				}
				if (line.length() > 2) {
					lines[row] = "�" + line;
				}
				row++;
			}
			if (line == null) done = true;
		} catch (Exception e) {
			e.printStackTrace();
			done = true;
		}
	}

	public void display(Screen screen) {
		screen.clear();

		for (int i = 0; i < 30; i++) {
			screen.drawString(lines[i], 3, i, 7);
		}
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_ACTION) {
			if (!done) {
				readNext();
			} else {
				setState(new TitleScreenState());
			}
		}
		if (key == KEY_BACK) {
			setState(new TitleScreenState());
		}
	}
}
