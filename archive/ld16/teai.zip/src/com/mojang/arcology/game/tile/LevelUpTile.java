package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.LevelUpState;
import com.mojang.arcology.game.mob.Mob;
import com.mojang.arcology.game.mob.Player;

public class LevelUpTile extends WallDecorationTile {
	public boolean tryMove(Level level, int x, int y, Mob mob) {
		if (!isSolid) return true;

		if (mob instanceof Player) {
			Player player = (Player) mob;
			if (player.xp == player.xpNext) {
				String msg = player.levelUp();
				level.pushState(new LevelUpState(player, msg));
			} else {
				level.addMessage("You're not ready to level up.");
			}
		}
		return !isSolid;
	}
}
