package com.mojang.arcology.game.item;

public class Key extends Item {
	public int keyColor;

	public Key(int keyColor) {
		this.keyColor = keyColor;
		if (keyColor == 0) {
			color = 1 + 8;
			name = "Blue keycard";
			addDescription("Opens blue doors");
		}
		if (keyColor == 1) {
			color = 2 + 8;
			name = "Green keycard";
			addDescription("Opens green doors");
		}
		if (keyColor == 2) {
			color = 4 + 8;
			name = "Red keycard";
			addDescription("Opens red doors");
		}
		weight = 1;
		value = 5;
		image = 9 * 32 + 1;
	}
}
