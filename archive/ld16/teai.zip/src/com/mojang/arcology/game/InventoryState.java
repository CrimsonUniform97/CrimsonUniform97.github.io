package com.mojang.arcology.game;

import java.util.List;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.game.item.Equipment;
import com.mojang.arcology.game.item.Item;
import com.mojang.arcology.game.mob.Player;

public class InventoryState extends State {
	private Player player;
	private List<Item> onGround;
	private int totalWeight = 0;
	private int totalValue = 0;
	private int mode = 0;
	private int[] selected = new int[3];

	public InventoryState(Player player, List<Item> onGround, int mode) {
		this.player = player;
		this.onGround = onGround;
		this.mode = mode;
	}

	public void display(Screen screen) {
		screen.clear();

		if (mode == 0) {
			screen.drawStringCenter("Inventory", 2, 14);
			displayItemList(screen, player.inventory, 5);
		} else if (mode == 1) {
			screen.drawStringCenter("On ground", 2, 14);
			displayItemList(screen, onGround, 5);
		} else if (mode == 2) {
			screen.drawStringCenter("Equipped", 2, 14);

			displaySlot(screen, "  Head:", 0, 5, 7);
			displaySlot(screen, " Torso:", 1, 6, 7);
			displaySlot(screen, "  Legs:", 2, 7, 7);

			displaySlot(screen, "Hand 1:", 3, 9, player.armCount >= 1 ? 7 : 4);
			displaySlot(screen, "Hand 2:", 4, 10, player.armCount >= 2 ? 7 : 4);
			displaySlot(screen, "Hand 3:", 5, 11, player.armCount >= 3 ? 7 : 4);
			displaySlot(screen, "Hand 4:", 6, 12, player.armCount >= 4 ? 7 : 4);
		}

		if (mode < 2) {
			int col = 8;
			if (mode == 0 && player.isOverBurdened()) {
				col = 4;
			}
			screen.drawStringRight("" + totalWeight / 10 + "." + totalWeight % 10 + "kg", 33, 4 + 21, col);
			screen.drawString("$" + totalValue, 34, 4 + 21, 8);
		}

		screen.drawStringCenter(",=Pick up   e=equip   d=drop   u=use", 27, 8);
		screen.drawStringCenter("<- Previous screen      Next screen ->", 28, 8);
	}

	private void displaySlot(Screen screen, String msg, int slot, int y, int col) {
		int x = 2;
		int coll = 0;
		if (slot == selected[mode]) {
			screen.drawString(">", x, y, 15);
			x += 1;
			if (col != 4) coll = 8;
		}
		displayItem(screen, x + 7, y, player.equipment[slot], coll);
		screen.drawString(msg, x, y, col + coll);
		if (slot == selected[mode]) {
			renderItemDescription(screen, player.equipment[slot]);
		}
	}

	private void displayItemList(Screen screen, List<Item> items, int y) {
		totalWeight = 0;
		totalValue = 0;

		int yo = selected[mode] - 9;
		if (yo > items.size() - 19) yo = items.size() - 19;
		if (yo < 0) yo = 0;
		for (int i = 0; i < items.size(); i++) {
			totalWeight += items.get(i).weight;
			totalValue += items.get(i).getSellValue();
		}
		for (int i = 0; i < 19; i++) {
			int slot = i + yo;
			if (slot < 0 || slot >= items.size()) continue;
			Item item = items.get(slot);

			int x = 1;
			int col = 0;
			if (slot == selected[mode]) {
				screen.drawString(">", x - 1, y + i, 15);
				x += 1;
				col = 8;
				renderItemDescription(screen, item);
			}

			displayItem(screen, x, y + i, item, col);

			screen.drawStringRight("" + item.weight / 10 + "." + item.weight % 10 + "kg", 33, y + i, 7 + col);
			screen.drawString("$" + item.getSellValue(), 34, y + i, 7 + col);
		}
	}

	private void renderItemDescription(Screen screen, Item item) {
		if (item == null) return;
		if (item.descriptions.size() == 0) return;

		String str = "";
		for (int j = 0; j < item.descriptions.size(); j++) {
			if (j > 0) str += ", ";
			str += item.descriptions.get(j);
		}
		screen.drawString(str, 1, 25, 9);
	}

	private void displayItem(Screen screen, int x, int y, Item item, int col) {
		if (item == null) return;
		screen.set(x, y, item.getImage(), item.getColor());
		screen.drawString(item.name, x + 2, y, item.textColor + col);
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_LEFT) mode--;
		if (key == KEY_RIGHT) mode++;
		if (key == KEY_UP) selected[mode]--;
		if (key == KEY_DOWN) selected[mode]++;

		if (mode < 0) mode = 2;
		if (mode > 2) mode = 0;

		if (selected[mode] < 0) selected[mode] = getMax() - 1;
		if (selected[mode] >= getMax()) selected[mode] = 0;

		if (key == KEY_BACK || key == KEY_ACTION) popState();
	}

	public void keyTyped(String letter) {
		if (letter.equals("D") && getMax() > 0) {
			if (mode == 0) {
				Item item = player.inventory.remove(selected[mode]);
				onGround.add(item);
			}
			if (selected[mode] >= getMax()) selected[mode] = getMax() - 1;

			if (mode == 2) {
				Item item = player.equipment[selected[mode]];
				if (item != null) {
					player.equipment[selected[mode]] = null;
					onGround.add(item);
				}
			}
		}
		if (letter.equals("U") && getMax() > 0) {
			if (mode == 1 || mode == 0) {
				Item item = getCurrentList().get(selected[mode]);
				if (item.use(player)) {
					getCurrentList().remove(item);
					if (selected[mode] >= getMax()) selected[mode] = getMax() - 1;
				}
			}
		}
		if (letter.equals(",") && getMax() > 0) {
			if (mode == 1) {
				Item item = onGround.remove(selected[mode]);
				player.inventory.add(item);
			}

			if (selected[mode] >= getMax()) selected[mode] = getMax() - 1;
		}
		if (letter.equals("E") && getMax() > 0) {
			if (mode == 2) {
				Item item = player.equipment[selected[mode]];
				if (item != null) {
					player.equipment[selected[mode]] = null;
					player.inventory.add(item);
				}
			} else {
				Item item = getCurrentList().get(selected[mode]);
				int slot = player.findEquipmentSlotFor(item);
				if (slot >= 0) {
					getCurrentList().remove(item);
					player.equipment[slot] = (Equipment) item;
				}
				if (selected[mode] >= getMax()) selected[mode] = getMax() - 1;
			}
		}
	}

	private List<Item> getCurrentList() {
		if (mode == 0) return player.inventory;
		if (mode == 1) return onGround;
		return null;
	}

	private int getMax() {
		if (mode == 0) return player.inventory.size();
		if (mode == 1) return onGround.size();
		return 7;
	}

}
