package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.item.Item;
import com.mojang.arcology.game.mob.Mob;
import com.mojang.arcology.game.mob.Player;

public class DoorTile extends Tile {
	public boolean locked = false;
	public int lockColor = 0;

	public int getImage(Level level, int x, int y) {
		if (level.isWall(x + 1, y)) return 32 * 2 + 6 + image;
		else return 32 * 3 + 6 + image;
	}

	public boolean tryMove(Level level, int x, int y, Mob mob) {
		if (!isSolid) return true;

		if (mob instanceof Player) {
			Player player = (Player) mob;
			if (locked) {
				Item key = player.getKey(lockColor);
				if (key != null) {
					level.setTile(x, y, Tile.openDoor);
					level.addActionMessage(mob, "unlock the door using a keycard", "unlocks a door");
					player.inventory.remove(key);
				} else {
					String color = "";
					if (lockColor == 0) color = "blue";
					if (lockColor == 1) color = "green";
					if (lockColor == 2) color = "red";
					level.addMessage("you need a " + color + " keycard");
				}
			} else {
				level.setTile(x, y, Tile.openDoor);
				level.addActionMessage(mob, "open the door", "opens a door");
			}
		}
		return !isSolid;
	}

	public DoorTile setLocked(int lock) {
		locked = true;
		lockColor = lock;

		return this;
	}

	public void close(Level level, int x, int y) {
		if (!isSolid && level.isFree(x, y) && level.getItems(x, y).size() == 0) {
			level.setTile(x, y, Tile.door);
			level.addMessage("You close the door");
		}
	}

}
