package com.mojang.arcology.game;

public class Pos {
	public final int x, y;

	public Pos(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int distanceTo(Pos p) {
		int xd = p.x-x;
		int yd = p.y-y;
		return xd*xd+yd*yd;
	}
}