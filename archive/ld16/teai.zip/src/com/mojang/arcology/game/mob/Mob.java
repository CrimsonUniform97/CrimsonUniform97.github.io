package com.mojang.arcology.game.mob;

import java.util.Random;

import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.Pos;
import com.mojang.arcology.game.tile.Tile;

public abstract class Mob {
	protected Random random = new Random();

	public int hp, hpMax;
	public int xpReward;

	public int x, y;
	public Level level;
	public int image;
	public int color = 15;
	public boolean isDead = false;
	public Faction faction = Faction.neutral;
	public String name = "A mob";
	public Gender gender = Gender.neuter;

	public int healTick = 0;
	public int healInterval = 5;

	public double nextMoveTime = 0;

	public boolean attemptMove(int xa, int ya) {
		if (level.tryMove(this, x + xa, y + ya)) {
			level.moveMob(this, x + xa, y + ya);
			x += xa;
			y += ya;
			return true;
		}
		return false;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public int getImage() {
		return image;
	}

	public int getColor() {
		return color;
	}

	public void tick() {
		healTick++;

		if (healTick >= healInterval) {
			healTick = 0;
			if (hp < hpMax) {
				hp++;
			}
		}
	}

	public void setPos(Pos pos) {
		this.x = pos.x;
		this.y = pos.y;
	}

	public void die() {
		isDead = true;
		level.removeMob(this);
	}

	public int getAttackDamage(Mob target) {
		int attack = getMelee();
		attack += random.nextInt(attack / 2) - random.nextInt(attack / 2);
		int def = (random.nextInt(target.getDef())+random.nextInt(target.getDef()))/2;

		int damage = attack - def;
		if (damage < 0) damage = 0;
		return damage;
	}

	private int getShootDamage(Mob target) {
		int attack = getAtk();
		attack += random.nextInt(attack / 2) - random.nextInt(attack / 2);
		int def = (random.nextInt(target.getDef())+random.nextInt(target.getDef()))/2;

		int damage = attack - def;
		if (damage < 0) damage = 0;
		return damage;
	}

	public boolean tryMove(Mob source) {
		if (source.faction.hates(faction)) {
			int dmg = source.getAttackDamage(this);
			hurt(source, dmg);
		}
		return false;
	}

	public void shoot(Mob source) {
		int dmg = source.getShootDamage(this);
		hurt(source, dmg);
	}

	protected void hurt(Mob source, int damage) {
		if (damage == 0) {
			String msg = source.getName() + " �8misses";
			if (source instanceof Player) {
				msg = "You �8miss";
			}
			level.addMessage(msg);
			return;
		}
		String msg = source.getName() + " hits for �4" + damage + "�7 damage";
		if (source instanceof Player) {
			msg = "You hit for �c" + damage + "�7 damage";
		}
		hp -= damage;
		if (hp <= 0) {
			die();
			if (level.getTile(x, y) == Tile.floor) level.setTile(x, y, Tile.blood);
			msg += ", killing " + getName();
		}
		level.addMessage(msg);
		if (isDead) source.kill(this);
	}

	public void kill(Mob mob) {
	}

	public String getName() {
		return name;
	}

	public abstract int getMelee();

	public abstract int getAtk();

	public abstract int getDef();

	public abstract int getSpeed();
}
