package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.mob.Mob;

public class Tile {
	public static Tile floor = new Tile().setSolid(false);
	public static Tile wall = new WallTile().setWall(true);
	public static Tile door = new DoorTile().setWall(true).setImage(0).setColor(7);
	public static Tile openDoor = new DoorTile().setWall(true).setImage(1).setSolid(false);
	public static Tile blueDoor = new DoorTile().setLocked(0).setColor(1+8).setWall(true).setImage(0);
	public static Tile greenDoor = new DoorTile().setLocked(1).setColor(2+8).setWall(true).setImage(0);
	public static Tile redDoor = new DoorTile().setLocked(2).setColor(4+8).setWall(true).setImage(0);
	public static Tile blood = new Tile().setSolid(false).setImage(32*8).setColor(4);
	public static Tile smallChest = new ChestTile(1).setImage(32*2+8).setColor(4);
	public static Tile mediumChest = new ChestTile(2).setImage(32*2+8).setColor(12);
	public static Tile largeChest = new ChestTile(3).setImage(32*2+8).setColor(14);

	public static Tile store = new StoreTile().setWall(true).setImage(9).setColor(14);
	public static Tile levelUp = new LevelUpTile().setWall(true).setImage(9).setColor(13);

	public static Tile stairsUp = new StairsTile(+1).setSolid(false).setImage(2*32+10).setColor(11);
	public static Tile stairsDown = new StairsTile(-1).setSolid(false).setImage(3*32+10).setColor(11);
	public static Tile beacon = new BeaconTile().setSolid(false).setImage(2*32+11).setColor(13);

	public static Tile bullet = new Tile().setImage(32*2+20).setColor(14);
	public static Tile bulletHit = new Tile().setImage(32*2+21).setColor(14);
	public static Tile bulletMiss = new Tile().setImage(32*2+21).setColor(12);

	public boolean isSolid = true;
	public boolean isWall = false;
	protected int image;
	public int color = 15;

	protected Tile setSolid(boolean solid) {
		this.isSolid = solid;
		return this;
	}

	protected Tile setWall(boolean wall) {
		this.isWall = wall;
		return this;
	}

	public Tile setImage(int image) {
		this.image = image;
		return this;
	}

	public int getImage(Level level, int x, int y) {
		return image;
	}

	public Tile setColor(int color) {
		this.color = color;
		return this;
	}

	public int getColor(Level level, int x, int y) {
		return color;
	}

	public boolean tryMove(Level level, int x, int y, Mob mob) {
		return !isSolid;
	}

	public void close(Level level, int x, int y) {
	}
}