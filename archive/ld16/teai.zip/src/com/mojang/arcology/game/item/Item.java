package com.mojang.arcology.game.item;

import java.util.ArrayList;
import java.util.List;

import com.mojang.arcology.game.mob.Player;

public class Item {
	public int image;
	public int color = 15;
	public int value;
	public int weight;
	public List<String> descriptions = new ArrayList<String>();

	public String name;
	public int textColor = 7;
	public int power;

	public int getImage() {
		return image;
	}

	public int getColor() {
		return color;
	}

	public int getSellValue() {
		return value / 10;
	}

	public void addDescription(String string) {
		descriptions.add(string);
	}

	public boolean use(Player player) {
		return false;
	}

	public int getBuyValue() {
		return value;
	}
}