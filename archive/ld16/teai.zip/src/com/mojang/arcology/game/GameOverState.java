package com.mojang.arcology.game;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.game.mob.Player;
import com.mojang.arcology.intro.TitleScreenState;

public class GameOverState extends State {
	private GameState gameState;

	public GameOverState(GameState gameState, Player player) {
		this.gameState = gameState;
	}

	public void display(Screen screen) {
		gameState.display(screen);
		screen.clear(0, 12, 40, 18);
		screen.drawString("gameovergameovergameovergameovergameover", 0, 11, 32);
		screen.drawString("meovergameovergameovergameovergameoverga", 0, 18, 32);

		screen.drawString("gameovergameovergameovergameovergameover", 0, 12, 4 + 16);
		screen.drawString("meovergameovergameovergameovergameoverga", 0, 17, 4 + 16);
		screen.drawStringCenter("YOU DIED", 14, 12);
		screen.drawStringCenter("Press escape to start over", 15, 7);
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_BACK) {
			setState(new TitleScreenState());
		}
	}
}
