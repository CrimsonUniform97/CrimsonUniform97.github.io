package com.mojang.arcology.game;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.game.item.Equipment;
import com.mojang.arcology.game.mob.Player;
import com.mojang.arcology.game.tile.Tile;
import com.mojang.arcology.game.win.WingameState;

public class GameState extends State {
	private Level level;
	private Player player;
	private List<String> messages = new ArrayList<String>();
	private Random random = new Random();

	private Level[] levels = new Level[16];

	public GameState(Player player) {
		this.player = player;
		travelToFloor(1, 0);
	}

	private void setLevel(Level level) {
		this.level = level;
		player.setLevel(level);
		level.addMob(player);
		level.resetLights();
		level.lightup(player.x, player.y, 10);
	}

	public void display(Screen screen) {
		screen.clear();
		level.display(screen, 0, 0, 29, 23, player.x, player.y);
		screen.drawString(player.name, 30, 1, 7);
		int yo = 2;
		int hpColor = 10;
		if (player.hp < player.hpMax) hpColor = 2;
		if (player.hp < player.hpMax / 3) hpColor = 4;
		screen.drawString("" + player.hp + "�7/�a" + player.hpMax, 30, yo++, hpColor);
		yo++;

		screen.drawString("LVL:�f" + player.xpLevel, 30, yo++, 7);
		screen.drawString(" XP:�f" + player.xp, 30, yo++, 7);
		screen.drawString("NXT:�f" + player.xpNext, 30, yo++, 7);
		if (player.xp == player.xpNext) {
			yo -= 2;
			screen.drawString(" XP:�d" + player.xp, 30, yo++, 7);
			screen.drawString("NXT:�d" + player.xpNext, 30, yo++, 7);
		}
		yo++;
		screen.drawString("STR:�f" + player.getStrString(), 30, yo++, 7);
		screen.drawString("DEX:�f" + player.getDexString(), 30, yo++, 7);
		screen.drawString("INT:�f" + player.getIntString(), 30, yo++, 7);
		yo++;
		screen.drawString("GUN:�f" + player.getAtk(), 30, yo++, 7);
		screen.drawString("MLE:�f" + player.getMelee(), 30, yo++, 7);
		screen.drawString("DEF:�f" + player.getDef(), 30, yo++, 7);
		screen.drawString("SPD:�f" + player.getSpeed(), 30, yo++, 7);
		yo++;
		screen.drawString("MNY:�f" + player.money, 30, yo++, 7);
		screen.drawString("AMM:�f" + (player.ammo == 0 ? "�4" : "") + player.ammo, 30, yo++, 7);
		yo++;
		screen.drawString("Press ?", 30, yo++, 8);
		screen.drawString("for help", 30, yo++, 8);

		for (int i = 0; i < 7; i++) {
			int row = messages.size() + i - 7;
			if (row >= 0) {
				screen.drawString(messages.get(row), 0, 23 + i, 7);
			}
		}
	}

	public void keyPressed(int key, boolean shifted) {
		if (player.isDead) return;
		if (key == KEY_ACTION) attemptMove(0, 0);

		if (shifted) {
			if (key == KEY_UP_LEFT) attemptFire(-1, -1);
			if (key == KEY_UP) attemptFire(0, -1);
			if (key == KEY_UP_RIGHT) attemptFire(+1, -1);
			if (key == KEY_LEFT) attemptFire(-1, 0);
			if (key == KEY_RIGHT) attemptFire(+1, 0);
			if (key == KEY_DOWN_LEFT) attemptFire(-1, +1);
			if (key == KEY_DOWN) attemptFire(0, +1);
			if (key == KEY_DOWN_RIGHT) attemptFire(+1, +1);
		} else {
			if (key == KEY_UP_LEFT) attemptMove(-1, -1);
			if (key == KEY_UP) attemptMove(0, -1);
			if (key == KEY_UP_RIGHT) attemptMove(+1, -1);
			if (key == KEY_LEFT) attemptMove(-1, 0);
			if (key == KEY_RIGHT) attemptMove(+1, 0);
			if (key == KEY_DOWN_LEFT) attemptMove(-1, +1);
			if (key == KEY_DOWN) attemptMove(0, +1);
			if (key == KEY_DOWN_RIGHT) attemptMove(+1, +1);
		}
	}

	public void keyTyped(String letter) {
		if (player.isDead) return;

		if (letter.equals("I")) {
			pushState(new InventoryState(player, level.getItems(player.x, player.y), 0));
		}
		if (letter.equals(",")) {
			pushState(new InventoryState(player, level.getItems(player.x, player.y), 1));
		}
		if (letter.equals("E")) {
			pushState(new InventoryState(player, level.getItems(player.x, player.y), 2));
		}
		if (letter.equals("C")) {
			for (int x = player.x - 1; x <= player.x + 1; x++)
				for (int y = player.y - 1; y <= player.y + 1; y++) {
					level.getTile(x, y).close(level, x, y);
				}
			level.resetLights();
			level.lightup(player.x, player.y, 10);
		}
	}

	private void attemptFire(int xa, int ya) {

		boolean hasGun = false;
		boolean hasAmmo = false;
		boolean hasTickedWorld = false;

		for (int i = 0; i < player.equipment.length; i++) {
			Equipment e = player.equipment[i];
			if (e != null && e.type == Equipment.GUN) {
				if (!hasTickedWorld) {
					player.nextMoveTime += 0.5 / player.getSpeed();
					tickWorld();
					hasTickedWorld = true;
				}
				hasGun = true;
				if (player.ammo >= e.ammoRequirement) {
					player.ammo -= e.ammoRequirement;
					hasAmmo = true;
					fireShot(xa, ya, 10, 4);
				}
			}
		}

		if (!hasGun) {
			addMessage("�4You haven't equipped a gun!");
		} else if (!hasAmmo) {
			addMessage("<click> �4You're out of ammo!");
		}

		level.resetLights();
		level.lightup(player.x, player.y, 10);
	}

	private void fireShot(int xa, int ya, int dist, int accuracy) {
		int xStart = player.x + xa;
		int yStart = player.y + ya;
		xa *= dist;
		ya *= dist;

		{
			double dd = dist / Math.sqrt(xa * xa + ya * ya);
			xa = (int) (xa * dd);
			ya = (int) (ya * dd);
		}

		xa += random.nextInt(accuracy) - random.nextInt(accuracy);
		ya += random.nextInt(accuracy) - random.nextInt(accuracy);

		int dd = Math.max(Math.abs(xa), Math.abs(ya));

		for (int i = 0; i <= dd; i++) {
			int x = (int) (xStart + (xa * i + xa / 2) / dd);
			int y = (int) (yStart + (ya * i + ya / 2) / dd);
			if (level.isSolid(x, y)) {
				level.setEffect(x, y, Tile.bulletMiss);
				return;
			}
			if (level.getMob(x, y) != null) {
				level.getMob(x, y).shoot(player);
				level.setEffect(x, y, Tile.bulletHit);
				return;
			}
			level.setEffect(x, y, Tile.bullet);
		}
	}

	private void attemptMove(int xa, int ya) {
		if (player.isOverBurdened()) {
			addMessage("�8You're overburdened and can't move!");
		} else {
			player.attemptMove(xa, ya);
		}
		player.tick();
		player.nextMoveTime += 1.0 / player.getSpeed();
		tickWorld();
		level.resetLights();
		level.lightup(player.x, player.y, 10);
	}

	private void tickWorld() {
		level.tick();

		if (player.isDead) {
			setState(new GameOverState(this, player));
		}
	}

	public void addMessage(String message) {
		messages.add(message);
	}

	private Level genLevel(int depth) {
		while (true) {
			try {
				Level level = new Level(this, 19 + depth * 4, 19 + depth * 4, depth);
//				if (depth < 16 && level.findStairs(1) == null) throw new RuntimeException("No stairs up!");
				if (depth > 1 && level.findStairs(-1) == null) throw new RuntimeException("No stairs down!");
				return level;
			} catch (RuntimeException e) {
				System.out.println("Bad level, retrying..");
			}
		}
	}

	public void travelToFloor(int depth, int dir) {
		if (level != null) {
			level.removeMob(player);
		}
		for (int i = 1; i <= 16; i++) {
			genLevel(i);
		}
		if (levels[depth - 1] == null) {
			levels[depth - 1] = genLevel(depth);
		}
		level = levels[depth - 1];

		if (dir == 0) {
			player.setPos(level.spawnPos);
		} else {
			player.setPos(level.findStairs(-dir));
		}
		addMessage("You enter floor " + depth);

		Tile.wall.color = (16 - depth) % 16;

		setLevel(level);
	}

	public void winGame() {
		setState(new WingameState());
	}
}