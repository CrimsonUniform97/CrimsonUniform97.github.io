package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;

public class WallTile extends Tile {
	public int getImage(Level level, int x, int y) {
		boolean u = level.isWall( x, y - 1);
		boolean d = level.isWall( x, y + 1);
		boolean l = level.isWall( x - 1, y);
		boolean r = level.isWall( x + 1, y);

		if (r && d) {
			if (isWall(level, x - 1, y + 0, x + 1, y + 1)) d = false;
			if (isWall(level, x + 0, y - 1, x + 1, y + 1)) r = false;
		}
		int offs = calcOffs(u, d, l, r);
		return 32 * 2 + offs + image * 3;
	}

	private int calcOffs(boolean u, boolean d, boolean l, boolean r) {
		if (!u && !d && !l && !r) return 32 + 1;
		if (r && d) return 0;
		if (l && r) return 1;
		if (u && d) return 32;
		if (r) return 2 + 32;
		if (d) return 1 + 32 * 2;
		if (l && u) return 32 * 2 + 2;
		if (l) return 2;
		if (u) return 32 * 2;
		return 2 + 32 * 2;
	}	

	private boolean isWall(Level level, int x0, int y0, int x1, int y1) {
		for (int x = x0; x <= x1; x++)
			for (int y = y0; y <= y1; y++)
				if (!level.isWall(x, y)) return false;
		return true;
	}
}
