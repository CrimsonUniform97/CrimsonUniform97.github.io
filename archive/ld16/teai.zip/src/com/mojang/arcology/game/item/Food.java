package com.mojang.arcology.game.item;

import com.mojang.arcology.game.mob.Player;
import com.mojang.arcology.game.mob.Player.Form;

public class Food extends Item {
	public Food(int power) {
		this.power = power;
		color = 4 + 8;
		image = 9 * 32 + 2;
		name = "Chicken club";
		weight = 5;
		value = 5;
	}

	public boolean use(Player player) {
		if (player.form != Form.Android && player.hp < player.hpMax) {
			player.hp += power;
			if (player.hp > player.hpMax) {
				player.hp = player.hpMax;
			}
			return true;
		}

		return false;
	}
}
