package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.mob.Mob;
import com.mojang.arcology.game.mob.Player;

public class ChestTile extends Tile {
	private int size;
	private static final String[] SIZENAMES = { "small", "large", "huge" };

	public ChestTile(int size) {
		this.size = size;
		this.isSolid = false;
	}

	public boolean tryMove(Level level, int x, int y, Mob mob) {
		if (mob instanceof Player) {
			level.setTile(x, y, Tile.floor);

			int itemCount = 0;
			for (int i = 0; i < (1<<size); i++) {
				itemCount += level.dropLoot(x, y);
			}
			if (itemCount == 0) level.addMessage("The " + SIZENAMES[size - 1] + " chest is empty");
			else level.addMessage("The " + SIZENAMES[size - 1] + " chest contains " + itemCount + " items");
		}
		return false;
	}
}
