package com.mojang.arcology.game.tile;

import com.mojang.arcology.game.Level;
import com.mojang.arcology.game.mob.Mob;
import com.mojang.arcology.game.mob.Player;

public class StairsTile extends Tile {
	public final int dir;
	
	public StairsTile(int dir) {
		this.dir = dir;
	}

	public boolean tryMove(Level level, int x, int y, Mob mob) {
		if (mob instanceof Player) {
			level.travelStairs(dir);
		}
		return false;
	}
}
