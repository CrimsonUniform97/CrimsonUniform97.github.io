package com.mojang.arcology.game.tile;

import java.util.List;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;
import com.mojang.arcology.game.item.Item;
import com.mojang.arcology.game.mob.Player;

public class StoreState extends State {
	private Player player;
	private List<Item> store;
	private int totalWeight = 0;
	private int totalValue = 0;
	private int mode = 0;
	private int[] selected = new int[2];

	public StoreState(Player player, List<Item> store) {
		this.player = player;
		this.store = store;
		this.mode = 1;
	}

	public void display(Screen screen) {
		screen.clear();

		if (mode == 0) {
			screen.drawStringCenter("Sell from Inventory", 2, 14);
			displayItemList(screen, player.inventory, 5);
		} else if (mode == 1) {
			screen.drawStringCenter("Buy from store", 2, 14);
			displayItemList(screen, store, 5);
		}

		screen.drawString("$"+player.money, 34, 2, 14);

		int col = 8;
		if (mode == 0 && player.isOverBurdened()) {
			col = 4;
		}
		screen.drawStringRight("" + totalWeight / 10 + "." + totalWeight % 10 + "kg", 33, 4 + 21, col);
		screen.drawString("$" + totalValue, 34, 4 + 21, 8);

		screen.drawStringCenter(",=buy       d=sell", 27, 8);
		screen.drawStringCenter("<- Previous screen      Next screen ->", 28, 8);
	}

	private void displayItemList(Screen screen, List<Item> items, int y) {
		totalWeight = 0;
		totalValue = 0;

		int yo = selected[mode] - 9;
		if (yo > items.size() - 19) yo = items.size() - 19;
		if (yo < 0) yo = 0;
		for (int i = 0; i < items.size(); i++) {
			totalWeight += items.get(i).weight;
			if (mode == 1) {
				totalValue += items.get(i).getBuyValue();
			} else {
				totalValue += items.get(i).getSellValue();
			}
		}
		for (int i = 0; i < 19; i++) {
			int slot = i + yo;
			if (slot < 0 || slot >= items.size()) continue;
			Item item = items.get(slot);

			int x = 1;
			int col = 0;
			if (slot == selected[mode]) {
				screen.drawString(">", x - 1, y + i, 15);
				x += 1;
				col = 8;
				renderItemDescription(screen, item);
			}

			displayItem(screen, x, y + i, item, col);

			screen.drawStringRight("" + item.weight / 10 + "." + item.weight % 10 + "kg", 33, y + i, 7 + col);

			if (mode == 1) {
				screen.drawString("$" + item.getBuyValue(), 34, y + i, (player.money >= item.getBuyValue() ? 7 : 4) + col);
			} else {
				screen.drawString("$" + item.getSellValue(), 34, y + i, 7 + col);
			}
		}
	}

	private void renderItemDescription(Screen screen, Item item) {
		if (item == null) return;
		if (item.descriptions.size() == 0) return;

		String str = "";
		for (int j = 0; j < item.descriptions.size(); j++) {
			if (j > 0) str += ", ";
			str += item.descriptions.get(j);
		}
		screen.drawString(str, 1, 25, 9);
	}

	private void displayItem(Screen screen, int x, int y, Item item, int col) {
		if (item == null) return;
		screen.set(x, y, item.getImage(), item.getColor());
		screen.drawString(item.name, x + 2, y, item.textColor + col);
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_LEFT) mode--;
		if (key == KEY_RIGHT) mode++;
		if (key == KEY_UP) selected[mode]--;
		if (key == KEY_DOWN) selected[mode]++;

		if (mode < 0) mode = 1;
		if (mode > 1) mode = 0;

		if (selected[mode] < 0) selected[mode] = getMax() - 1;
		if (selected[mode] >= getMax()) selected[mode] = 0;

		if (key == KEY_BACK || key == KEY_ACTION) popState();
	}

	public void keyTyped(String letter) {
		if (letter.equals("D") && getMax() > 0) {
			if (mode == 0) {
				Item item = player.inventory.remove(selected[mode]);
				store.add(item);
				player.money += item.getSellValue();
			}
			if (selected[mode] >= getMax()) selected[mode] = getMax() - 1;
		}
		if (letter.equals(",") && getMax() > 0) {
			if (mode == 1) {
				Item item = store.get(selected[mode]);
				if (player.money >= item.getBuyValue()) {
					player.money -= item.getBuyValue();
					store.remove(item);
					player.inventory.add(item);
				}
			}

			if (selected[mode] >= getMax()) selected[mode] = getMax() - 1;
		}
	}

	private int getMax() {
		if (mode == 0) return player.inventory.size();
		if (mode == 1) return store.size();
		return 7;
	}

}
