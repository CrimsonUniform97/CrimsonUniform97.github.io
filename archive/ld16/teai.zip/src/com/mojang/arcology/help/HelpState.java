package com.mojang.arcology.help;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.mojang.arcology.Screen;
import com.mojang.arcology.State;

public class HelpState extends State {
	private BufferedReader br;
	private boolean readNextLine = true;
	private boolean done = false;

	public void display(Screen screen) {
		if (!readNextLine)
			return;

		readNextLine = false;
		screen.clear();
		try {
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(HelpState.class.getResourceAsStream("help.txt")));
			}
			String line = "";
			int row = 3;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("-")) {
					break;
				}
				if (line.length() > 2) {
					screen.drawString(line.substring(2), 4, row, Integer.parseInt(line.substring(0, 1), 16));
				}
				row++;
			}
			if (line == null)
				done = true;
		} catch (Exception e) {
			screen.drawString("Failed to read intro", 4, 4, 15);
			e.printStackTrace();
			done = true;
		}
	}

	public void keyPressed(int key, boolean shifted) {
		if (key == KEY_BACK) {
			popState();
		}
		if (key == KEY_ACTION) {
			if (!done) {
				readNextLine = true;
			} else {
				popState();
			}
		}
	}
}
