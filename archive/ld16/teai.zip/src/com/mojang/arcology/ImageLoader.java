package com.mojang.arcology;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageLoader {
	public static BufferedImage load(String resourceName) throws IOException {
		BufferedImage org = ImageIO.read(FontSheet.class.getResourceAsStream(resourceName));
		BufferedImage converted = new BufferedImage(org.getWidth(), org.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics g = converted.getGraphics();
		g.drawImage(org, 0, 0, null);
		g.dispose();
		return converted;
	}
}
