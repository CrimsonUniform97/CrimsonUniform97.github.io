package com.mojang.arcology;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class Screen {
	private int[] images;
	private int[] cols;
	public final int width, height;

	private Image image;
	private Graphics g;
	private Image[][] fontSheet;
	public boolean hasFocus;

	private BufferedImage overlay;
	private BufferedImage focusOverlay;

	private static final String CHAR_MAP = "" + //
			" ABCDEFGHIJKLMNOPQRSTUVWXYZ@���$" + //
			"0123456789.,:;!?'\"-+/\\[](){}<>=%";

	public Screen(int width, int height, Image[][] fontSheet) {
		this.width = width;
		this.height = height;
		this.fontSheet = fontSheet;

		images = new int[width * height];
		cols = new int[width * height];

		{
			double nn = Math.random() * 0.1f;
			overlay = new BufferedImage(width * 8, height * 8, BufferedImage.TYPE_INT_ARGB);
			int[] pixels = new int[width * height * 8 * 8];
			for (int y = 0; y < height * 8; y++) {
				for (int x = 0; x < width * 8; x++) {
					double xd = (x / (width * 8 - 1.0) - 0.5f) / 0.8;
					double yd = (y / (height * 8 - 1.0) - 0.5f) / 0.8;
					double d = Math.sqrt(xd * xd + yd * yd);

					if (Math.random() < 0.2f) {
						nn = Math.random() * 0.1f;
					}

					int a = (int) ((d * d * d * d + nn + Math.random() * Math.random() * 0.1) * 200);
					int r = 0;
					int g = 0;
					int b = 0;

					int col = a << 24 | r << 16 | g << 8 | b;
					pixels[x + y * width * 8] = col;
				}
			}
			overlay.setRGB(0, 0, width * 8, height * 8, pixels, 0, width * 8);
			image = new BufferedImage(width * 8, height * 8, BufferedImage.TYPE_INT_RGB);
			g = image.getGraphics();
		}
		
		try {
			focusOverlay = ImageLoader.load("/focusoverlay.png");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void set(int x, int y, int image, int col) {
		if (x < 0 || y < 0 || x >= width || y >= height) return;
		images[x + y * width] = image;
		cols[x + y * width] = col;
	}

	public void drawString(String string, int x, int y, int col) {
		if (y < 0 || y >= height) return;

		string = string.toUpperCase();
		for (int i = 0; i < string.length(); i++) {
			if (x + i < 0 || x + i >= width) continue;

			char ch = string.charAt(i);
			if (ch == '�') {
				i++;
				col = Integer.parseInt("" + string.charAt(i), 16);
				x -= 2;
				continue;
			}
			int p = CHAR_MAP.indexOf(ch);
			if (p < 0) p = 0;
			images[x + i + y * width] = p;
			cols[x + i + y * width] = col;
		}
	}

	public Image getImage() {
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				int p = x + y * width;
				g.drawImage(fontSheet[images[p]][cols[p]], x * 8, y * 8, null);
			}
		}
		
		if (!hasFocus && focusOverlay!=null)
		{
			g.drawImage(focusOverlay, 0, 0, null);
		}

		g.drawImage(overlay, 0, 0, null);

		return image;
	}

	public void clear() {
		for (int i = 0; i < width * height; i++) {
			images[i] = 0;
			cols[i] = 0;
		}
	}

	public void clear(int x0, int y0, int x1, int y1) {
		for (int x = x0; x < x1; x++)
			for (int y = y0; y < y1; y++) {
				images[x + y * width] = 0;
				cols[x + y * width] = 0;
			}
	}

	public void drawStringCenter(String string, int y, int col) {
		drawString(string, (width - string.length()) / 2, y, col);
	}

	public void drawStringRight(String string, int x, int y, int col) {
		drawString(string, x - string.length(), y, col);
	}
}