package com.mojang.arcology;

import java.util.Random;

public class Dice {
	private static Random random = new Random();

	public static int roll(int sides, int count) {
		int sum = 0;
		for (int i = 0; i < count; i++)
			sum += random.nextInt(sides);
		return sum + count;
	}
}