package com.mojang.arcology;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class FontSheet {
	private BufferedImage[][] images;

	public FontSheet(String resourceName) {
		try {
			BufferedImage sheet = ImageLoader.load(resourceName);

			int width = sheet.getWidth() / 8;
			int height = sheet.getHeight() / 8;
			this.images = new BufferedImage[width * height][33];

			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					int[] srcPixels = new int[8 * 8];
					int[] dstPixels = new int[8 * 8];

					sheet.getRGB(x * 8, y * 8, 8, 8, srcPixels, 0, 8);
					for (int col = 0; col < 33; col++) {
						int rCol = ((col >> 2) & 1) * 170;
						int gCol = ((col >> 1) & 1) * 170;
						int bCol = ((col >> 0) & 1) * 170;
						if ((col & 15) > 7) {
							rCol += 85;
							gCol += 85;
							bCol += 85;
						}

						for (int i = 0; i < 8 * 8; i++) {
							int color = srcPixels[i];

							int r = ((color >> 16) & 0xff);
							int g = ((color >> 8) & 0xff);
							int b = ((color) & 0xff);

							if (r == g && g == b) {
								// This is gray! Keep the color as-is.
							} else if (g == 0 && r == b) {
								// Magic pink! Turn black
								r = g = b = 0;
								if (y == 6) {
									if (i != 0 && i != 7 && i != 63 - 7 && i != 63) {
										r = 90;
									}
								}
								if (y == 5) {
									if (i != 0 && i != 7 && i != 63 - 7 && i != 63) {
										r = g = 50;
									}
								}
								if (y > 8) {
									if (i != 0 && i != 7 && i != 63 - 7 && i != 63) {
										b = 90;
									}
								}
							} else {
								r = g * rCol / 255;
								b = g * bCol / 255;
								g = g * gCol / 255;
							}
							r = r * (255 - 60) / 255;
							g = g * (255 - 60) / 255;
							b = b * (255 - 60) / 255;
							r += 60;
							g += 60;
							b += 60;

							if (col == 32) {
								r = g = b = 24;
							} else if (col >= 16) {
								r = r / 5 + 24;
								g = g / 5 + 24;
								b = b / 5 + 24;
							}

							dstPixels[i] = (r << 16) | (g << 8) | b;
						}

						int p = x + y * width;
						images[p][col] = new BufferedImage(8, 8, BufferedImage.TYPE_INT_RGB);
						images[p][col].setRGB(0, 0, 8, 8, dstPixels, 0, 8);
					}
				}
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public Image[][] getImages() {
		return images;
	}
}