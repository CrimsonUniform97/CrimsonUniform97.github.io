The Europa Arcology Incident
This is an entry to the 16th Ludum Dare competiton

Copyright 2009 Markus Persson
You may not make derivative works of this game.

To run the game, open the index.html page in a web browser.
Make sure you have java installed.

For instructions, press ? in the game.

You can reach me at markus@mojang.com

