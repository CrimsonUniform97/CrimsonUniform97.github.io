/*
 * ScortchedEarthlet.java
 *
 * Created on September 6, 2002, 6:33 mM
 */

package com.cprince.game;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author  radix_zero
 */
public class se extends JApplet implements ActionListener {
    
    private St g;

    private JSpinner p;
    
    private JSpinner aM;
    
    private JButton fB;
    
    private boolean pT;
    
   
    private Sp l;
    private Sp m;

    public void init() {
        super.init();
        Container cPn = this.getContentPane();
        cPn.setLayout( new BorderLayout() );
        // setup terrain
        this.l = new Sp( (float)Math.random(), Color.red);
        this.m = new Sp( (float)Math.random(), Color.yellow);
        g = new St((float)(Math.random()*500), (float)(Math.random()*500), (float)(Math.random()*500), (float)(Math.random()*500), l, m );

        cPn.add(g, BorderLayout.CENTER );
        
        // set up controls
        JPanel cp = new JPanel();
        cp.setPreferredSize( new Dimension( 500, 100 ) );
        cPn.add( cp, BorderLayout.SOUTH );
        
        cp.add( new JLabel("p") );
        
        p = new JSpinner();
        p.setPreferredSize( new Dimension( 50, 25 ) );
        cp.add(p);
        
        cp.add(new JLabel("a"));
        
        aM = new JSpinner();
        aM.setPreferredSize( new Dimension( 50, 25 ) );
        cp.add(aM);
        
        fB = new JButton("F");
        fB.addActionListener( this );
        cp.add( fB );
        
        this.pT = true;
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) {
        
        Sp n;
        Sp u;
        
        if( this.pT ) {           
            n = this.l;
            u = this.m;
        } else {
            n = this.m;
            u = this.l;
        }
        
        n.fr = true;
        n.ag = (float)(((Integer)this.aM.getValue()).floatValue()/57.296);
        n.pr = ((Integer)this.p.getValue()).floatValue();
        
        u.fr = false;
        this.pT = !this.pT;

        this.g.repaint();
    }
    
}
