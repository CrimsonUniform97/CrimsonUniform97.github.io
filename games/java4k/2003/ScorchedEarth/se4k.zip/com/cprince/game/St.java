/*
 * Ter.java
 *
 * Created on September 6, 2002, 6:42 PM
 */

package com.cprince.game;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;


public class St extends Canvas  {
    
    float a;
    float b;
    float c;
    float d;
    
    float [] y;
    
    boolean cl = false;
    
    Sp l;
    Sp m;
    
    float w;
    float h;
    
    /** C9reates a new instance of Ter */
    public St(float x1, float x2, float x3, float x4, Sp l, Sp m) {
        super();
        
        mQ( x1, x2, x3, x4 );
        this.setSize(500,300);
        
        pT();
        this.setPlr(l, m);
        
        this.setForeground( Color.green );
    }
    
    
    public void pT() {
        float mx = 0.0f;
        float mn = 0.0f;
        w = (float)getSize().getWidth();
        h = (float)getSize().getHeight();
        
        this.y = new float[(int)w];
        
        // get all the points
        for( int i=0; i<((int)w); i++ ) {
            y[i] = (float)(Math.pow(i,4) + a*Math.pow(i,3)+ b*Math.pow(i,2) + c*i + d);
            if( y[i] > mx )
                mx = y[i];
            if( y[i] < mn )
                mn = y[i];
        }
        
        // scale points
        for(int i=0; i<((int)w); i++ ) {
            y[i] = h - (float)((y[i]+(mx-mn))/(mx+(mx-mn))*h/2);
        }
        
    }
    
    
    public void setPlr( Sp l, Sp m ) {
        
        l.x = (float)(Math.random()*w);
        m.x = (float)(Math.random()*w);
        
        l.y = this.y[(int)l.x];
        m.y = this.y[(int)m.x];
        
        this.l = l;
        this.m = m;
        l.tr = this;
        m.tr = this;
    }
    
    public void paint( Graphics g ) {
        Graphics2D g2d = (Graphics2D)g;
        
        if( this.cl ) {
            g2d.setPaint( Color.lightGray );
            g2d.fillRect(0,0,(int)w,(int)h);
            cl = false;
        }
        
        g2d.setPaint( Color.blue );
        GeneralPath Ter = new GeneralPath();
        
        Ter.moveTo( (float)w, (float)y[(int)w-1] );
        Ter.lineTo( (float)w, (float)h );
        Ter.lineTo( (float)0, (float)h );
        
        for( int j=0; j<w; j+=1 ) {
            Ter.lineTo( (float)j, (float)y[j] );
        }
        
        g2d.fill( Ter );
        
        l.Dr(g2d, w, h, m);
        m.Dr(g2d, w, h, l);
        
    }
    
    public void mQ( float e, float f, float g, float h ) {
        a = -( e + f + g + h );
        b = e*f + f*g + g*h + e*g + e*h;
        c = -( e*f*g + e*f*g + e*f*h + e*g*h );
        d = e*f*g*h;
    }
    
    public void reset() {
        mQ( (float)(Math.random()*500), (float)(Math.random()*500), (float)(Math.random()*500), (float)(Math.random()*500));
        pT();
        
        setPlr(l,m);
        
        l.fr = false;
        m.fr = false;
        cl = true;
        this.repaint();
    }
    
}
