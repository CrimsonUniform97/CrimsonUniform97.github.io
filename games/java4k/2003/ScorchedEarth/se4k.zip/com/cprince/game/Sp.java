package com.cprince.game;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class Sp {
    
    public float x;
    public float y;
    public Color c;
    
    public float pr;
    public float ag;
    public boolean fr = false;
    public int s = 0;
    public boolean buE = false;
    
    public St tr;
    
    public Sp(float x, Color c) {
        this.x = x;
        this.c = c; 
    }
    
    public void Dr( Graphics2D g2d, float w, float h, Sp target ) {
        g2d.setPaint( this.c );
        
        GeneralPath one = new GeneralPath(GeneralPath.WIND_EVEN_ODD);
        
        one.moveTo( x-10, y );
        one.lineTo( x+10, y );
        one.lineTo( x, y-20 );
        one.lineTo( x-10, y );
        g2d.fill(one);

        if( this.fr ) {
            g2d.setPaint( Color.blue );
            
            for( float t=0; t<w; t += 0.1 ) {
                
                float x = (float)((pr*Math.cos(ag))*t + (this.x));
                float y = (float)(h - ((pr*Math.sin(ag))*t - 19.6*t*t + (h-(float)(this.y-20))));

                if( (x >= w) || (x < 0) )
                    break;
                else 
                    g2d.fillRect( (int)x,(int)y,1,1 );
                
                if( target.hit(x,y) ) {
                    this.s++;
                    this.buE = true;
                    this.tr.reset();
                    break;
                }
            }
        }        
    }

    public boolean hit( float s, float t ) {
        return ( s >= (x-10) ) && ( s < (x+10) ) && ( t < y ) && ( t >= (y-20) );
    }

}
