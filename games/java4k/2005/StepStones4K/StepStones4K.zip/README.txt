date: Jan 30th 2005
Java 4k Game Contest #3
_______________________________________________________________________________

title:             Step Stones 4k
file:              stepstone.zip
author:            Stephan Ryer
email address:     StephanRyer@hotmail.com
Homepage:          www.bigbabies.dk
description:       3D 4k 5star game :D
_______________________________________________________________________________

game information

single player:     yes
multi player:      no

java version:      1.5+
tested platforms:  win

double clickable:  no
applet:            no
webstart:          no

sound:             no
music:             no
images:            no

2d, fake 3d or 3d: fake 3d

how to play        extract the contents of this zip file

		   For OpenGL mode (Not supported byt all video cards):
                   java -Dsun.java2d.opengl=true -classpath stepstones.zip A

		   For Software mode:
		   java -classpath stepstones.zip A
_______________________________________________________________________________

known bugs:        none
_______________________________________________________________________________

NOTES

Use the arrow keys to move from side to side. Avoid hitting a hole for as long time as possible.
_______________________________________________________________________________

Java and the Java logo are both Copyright � 1994-2005 Sun Microsystems, Inc.

This game may be electronically distributed only at 
NO CHARGE to the recipient in its current state, MUST 
include this .txt file, and may NOT be modified IN 
ANY WAY. UNDER NO CIRCUMSTANCES IS THIS GAME TO BE 
DISTRIBUTED ON CD-ROM WITHOUT PRIOR WRITTEN PERMISSION.
_______________________________________________________________________________