Controls:
WASD - Move around.
E - Open/close weapon and block customization window.
1 - Select Block Gun.
2 - Select Weapon One.
3 - Select Weapon Two.
Tab - Open/close console for input.
Left click - Fire weapon or place block.
Right click - Remove block.

Console Commands:
help - bring up a list of possible commands
quit - quit the game
kill - kill your character and respawn
weapon1 <weapon string> - set weapon one to <weapon string>
weapon2 <weapon string> - similar to weapon1

Admin Commands:
These may only be used by a client connected to the server locally.
admin_clear_map - Clear all blocks from the map.
admin_save <name> - Saves the current map to <name>.map
admin_load <name> - Clears the map and loads the map from <name>.map into the game.
admin_war_peace - Switches from war mode to peace mode and vice versa.

Helpful hints:
* You can make a sprite with the sprite editor and use it during deathmatch games.
* You may build during peace-time only.
* You may shoot during war-time only.
* You begin with 100 health points (red bar) and 100 energy points (blue bar).
* To begin building, fire a block at the ground with the block gun.
* Blocks may be stuck either to the ground or to other blocks.
* You may only build on light colored squares.
* You can set your weapon to options not specified in the customization menu with the weaponX commands.